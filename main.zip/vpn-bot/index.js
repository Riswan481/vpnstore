const { Telegraf, Markup } = require('telegraf');
const { NodeSSH } = require('node-ssh');
const moment = require('moment');
const fs = require('fs');
const fetch = require('node-fetch');
const cron = require('node-cron');

// ================== CONFIG ==================
const BOT_TOKEN = '8109663922:AAFQbxSakJGxn6uPj5ry8nqqYeqeQNfGhRs';
const OWNER_ID = 7545471466; // ganti dengan ID Telegram admin
const vpsFile = './vps_list.json';
const resellerFile = './reseller_accounts.json';

const bot = new Telegraf(BOT_TOKEN);

// ================== DATA HANDLER ==================
function loadVPS() {
    return fs.existsSync(vpsFile) ? JSON.parse(fs.readFileSync(vpsFile)) : [];
}
function saveVPS(vpsList) {
    fs.writeFileSync(vpsFile, JSON.stringify(vpsList, null, 2));
}
function loadResellerAccounts() {
    return fs.existsSync(resellerFile) ? JSON.parse(fs.readFileSync(resellerFile)) : [];
}
function saveResellerAccount({ username, owner, type, expiredDate }) {
    const db = loadResellerAccounts();
    db.push({ username, owner, type, expiredDate });
    fs.writeFileSync(resellerFile, JSON.stringify(db, null, 2));
}
function isOwner(id) {
    return id === OWNER_ID;
}

// ================== STATE (Wizard) ==================
let userState = new Map();

// ================== COMMANDS ==================
bot.command('addvps', (ctx) => {
    if (!isOwner(ctx.from.id)) return ctx.reply('❌ Hanya admin yang bisa menambahkan VPS.');
    const args = ctx.message.text.split(' ')[1];
    if (!args || !args.includes('|')) return ctx.reply('❌ Format: /addvps host|username|password');
    const [host, username, password] = args.split('|');
    if (!host || !username || !password) return ctx.reply('❌ Semua field harus diisi.');

    const vpsList = loadVPS();
    vpsList.push({ host, username, password });
    saveVPS(vpsList);

    ctx.reply(`✅ VPS berhasil ditambahkan:\n🌐 Host: ${host}\n👤 Username: ${username}`);
});

bot.command('listvps', (ctx) => {
    const vpsList = loadVPS();
    if (!vpsList.length) return ctx.reply('⚠️ Belum ada VPS.');
    let teks = '📋 *Daftar VPS:*\n';
    vpsList.forEach((v, i) => {
        teks += `\n${i + 1}. 🌐 ${v.host}\n   👤 ${v.username}`;
    });
    ctx.reply(teks, { parse_mode: 'Markdown' });
});

bot.command('hapusvps', (ctx) => {
    if (!isOwner(ctx.from.id)) return ctx.reply('❌ Hanya admin yang bisa menghapus VPS.');
    const args = ctx.message.text.split(' ')[1];
    if (!args) return ctx.reply('❌ Gunakan: /hapusvps nomor');
    const vpsList = loadVPS();
    const index = parseInt(args) - 1;
    if (isNaN(index) || index < 0 || index >= vpsList.length) return ctx.reply('❌ Nomor VPS tidak valid.');
    const removed = vpsList.splice(index, 1);
    saveVPS(vpsList);
    ctx.reply(`✅ VPS ${removed[0].host} berhasil dihapus.`);
});

bot.command('menu', async (ctx) => {
    if (!isOwner(ctx.from.id)) {
        return ctx.reply('❌ Hanya admin yang bisa akses menu ini.');
    }

    const vpsList = loadVPS();
    if (!vpsList.length) return ctx.reply('⚠️ Belum ada VPS.');

    const vpsButtons = vpsList.map((v, i) => Markup.button.callback(`${i + 1}. ${v.host}`, `vps_${i}`));
    await ctx.reply(
  '🚀 Siap meluncur!\nPilih VPS tercepat untukmu:',
  Markup.inlineKeyboard(vpsButtons, { columns: 1 }));
});

// ================== CALLBACK HANDLER ==================
bot.on('callback_query', async (ctx) => {
    const data = ctx.callbackQuery.data;
    const chatId = ctx.callbackQuery.from.id;

    if (!isOwner(chatId)) {
        return ctx.answerCbQuery('❌ Hanya admin yang bisa melakukan ini.', { show_alert: true });
    }

    if (!userState.has(chatId)) userState.set(chatId, {});
    const state = userState.get(chatId);

    // Pilih VPS
    if (data.startsWith('vps_')) {
        const index = parseInt(data.split('_')[1]);
        state.selectedVPS = index;
        userState.set(chatId, state);

        await ctx.reply(
    `✅ VPS dipilih: ${loadVPS()[index].host}\n\nPilih opsi:`,
    Markup.inlineKeyboard([
        [Markup.button.callback('⚡ Buat Akun SSH', 'buat_akun')],
        [Markup.button.callback('🎁 Trial 1 Hari', 'trial_akun')],
        [Markup.button.callback('🗑 Hapus User', 'hapus_user')],
        [Markup.button.callback('📋 List User', 'list_user')]
    ]));
        return ctx.answerCbQuery();
    }

    // Mulai wizard buat akun normal
    if (data === 'buat_akun') {
        state.step = 'username';
        userState.set(chatId, state);
        await ctx.reply('👤 Masukkan username:');
        return ctx.answerCbQuery();
    }

    // Buat akun trial otomatis
    if (data === 'trial_akun') {
        state.step = null;
        state.username = `trial${Math.floor(Math.random() * 1000)}`;
        state.expiredDays = 1;
        state.maxIP = 1;

        await ctx.reply('⏳ Membuat akun trial 1 hari...');
        await buatSSH(ctx, state, true); // true = trial
        return ctx.answerCbQuery();
    }

    // List user
    if (data === 'list_user') {
        const users = loadResellerAccounts();
        const sshConfig = loadVPS()[state.selectedVPS];
        if (!users.length) return ctx.reply('⚠️ Belum ada user.');

        // Filter user berdasarkan owner
        const filtered = users.filter(u => u.owner === chatId.toString());
        if (!filtered.length) return ctx.reply('⚠️ Tidak ada user untuk VPS ini.');

        let text = `📋 *Daftar User VPS ${sshConfig.host}:*\n\n`;
        filtered.forEach((u, i) => {
            text += `${i + 1}. 👤 ${u.username} | ${u.type} | Expired: ${u.expiredDate}\n`;
        });

        await ctx.reply(text, { parse_mode: 'Markdown' });
        return ctx.answerCbQuery();
    }

    // Hapus User
    if (data === 'hapus_user') {
        const users = loadResellerAccounts();
        const filtered = users.filter(u => u.owner === chatId.toString());
        if (!filtered.length) return ctx.reply('⚠️ Tidak ada user untuk dihapus.');

        const buttons = filtered.map((u, i) => [Markup.button.callback(`❌ ${u.username}`, `hapus_${i}`)]);
        await ctx.reply('🗑 Pilih user untuk dihapus:', Markup.inlineKeyboard(buttons, { columns: 1 }));
        return ctx.answerCbQuery();
    }

    // Callback hapus user spesifik
    if (data.startsWith('hapus_')) {
        const idx = parseInt(data.split('_')[1]);
        const users = loadResellerAccounts();
        const filtered = users.filter(u => u.owner === chatId.toString());
        const userToDelete = filtered[idx];
        if (!userToDelete) return ctx.answerCbQuery('❌ User tidak ditemukan', { show_alert: true });

        const ssh = new NodeSSH();
        const sshConfig = loadVPS()[state.selectedVPS];
        try {
            await ssh.connect(sshConfig);
            await ssh.execCommand(`userdel -r ${userToDelete.username}`);
            const newDB = users.filter(u => u.username !== userToDelete.username || u.owner !== chatId.toString());
            fs.writeFileSync(resellerFile, JSON.stringify(newDB, null, 2));

            await ctx.reply(`✅ User ${userToDelete.username} berhasil dihapus.`);
        } catch (err) {
            await ctx.reply(`❌ Gagal hapus user: ${err.message}`);
        } finally {
            if (ssh.isConnected()) ssh.dispose();
        }
        return ctx.answerCbQuery();
    }
});

// ================== WIZARD INPUT ==================
bot.on('text', async (ctx) => {
    const chatId = ctx.from.id;
    if (!userState.has(chatId)) return;
    if (!isOwner(chatId)) return ctx.reply('❌ Hanya admin yang bisa membuat akun.');

    const state = userState.get(chatId);
    const msg = ctx.message.text.trim();

    if (state.step === 'username') {
        state.username = msg;
        state.step = 'expired';
        userState.set(chatId, state);
        return ctx.reply('📅 Masukkan masa aktif (hari):');
    }

    if (state.step === 'expired') {
        state.expiredDays = parseInt(msg);
        state.step = 'maxip';
        userState.set(chatId, state);
        return ctx.reply('🌐 Masukkan limit IP:');
    }

    if (state.step === 'maxip') {
        state.maxIP = parseInt(msg);
        state.step = null;

        await ctx.reply('⏳ Membuat akun mohon tunggu...');
        return buatSSH(ctx, state); 
    }
});
// ================== FUNGSI BUAT SSH ==================
async function buatSSH(ctx, state, isTrial = false) {
    const vpsList = loadVPS();
    const ssh = new NodeSSH();
    const sshConfig = vpsList[state.selectedVPS];

    const username = state.username || `user${Math.floor(Math.random() * 1000)}`;
    const password = Math.random().toString(36).slice(-8);
    const expiredDays = state.expiredDays;
    const maxIP = state.maxIP;
    const expiredDate = moment().add(expiredDays, 'days').format('YYYY-MM-DD');

    try {
        await ssh.connect(sshConfig);

        await ssh.execCommand(`
            useradd -e ${expiredDate} -M -s /bin/false ${username} && \
            echo "${username}:${password}" | chpasswd
        `);

        saveResellerAccount({ username, owner: ctx.from.id.toString(), type: isTrial ? 'trial' : 'ssh', expiredDate });

        return ctx.reply(
`====================================
${isTrial ? '🎁 *Trial UDP 1 Hari*' : '✅ *Berhasil Membuat Akun UDP*'}

🌐 *Host:* \`${sshConfig.host}\`
👤 *Username:* \`${username}\`
🔑 *Password:* \`${password}\`
📅 *Expired:* ${expiredDate}
📶 *IP Limit:* ${maxIP} login
====================================
🔗 *Format udp :*
\`${sshConfig.host}:1-65535@${username}:${password}\`
====================================
👤 *Admin Telegram:* [Klik disini](https://t.me/JesVpnt)
🌐 *Grup Telegram:* [Klik disini](https://t.me/grupvpn)
📱 *Admin WA:* [Klik disini](https://wa.me/6285888801241)
📄 *Saluran WA:* [Klik disini](https://whatsapp.com/channel/0029VamUr1QJuyAFhT7ife3K)
====================================`,
{ parse_mode: 'Markdown' }
);
    } catch (err) {
        return ctx.reply(`❌ Gagal koneksi VPS atau membuat akun:\n${err.message}`);
    } finally {
        if (ssh.isConnected()) ssh.dispose();
    }
}

// ================== HAPUS USER OTOMATIS ==================
async function hapusUserExpired() {
    const users = loadResellerAccounts();
    const vpsList = loadVPS();
    const now = moment();

    for (const vps of vpsList) {
        const ssh = new NodeSSH();
        try {
            await ssh.connect(vps);
            
            for (const user of users) {
                if (!user.expiredDate) continue;
                const expDate = moment(user.expiredDate, 'YYYY-MM-DD');
                if (now.isAfter(expDate)) {
                    await ssh.execCommand(`userdel -r ${user.username}`);
                    console.log(`✅ User ${user.username} dihapus dari ${vps.host}`);
                }
            }
        } catch (err) {
            console.log(`❌ Gagal koneksi ke VPS ${vps.host}: ${err.message}`);
        } finally {
            if (ssh.isConnected()) ssh.dispose();
        }
    }

    const newDB = users.filter(u => !u.expiredDate || moment(u.expiredDate, 'YYYY-MM-DD').isAfter(now));
    fs.writeFileSync(resellerFile, JSON.stringify(newDB, null, 2));
}

// Cron job setiap jam 00:00
cron.schedule('0 0 * * *', () => {
    console.log('⏰ Mengecek user expired...');
    hapusUserExpired();
});

// ================== START BOT ==================
bot.launch();
console.log('🤖 Bot SSH multi-server berjalan...');