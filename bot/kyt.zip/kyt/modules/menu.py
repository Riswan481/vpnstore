from kyt import *
from datetime import datetime
import subprocess
import json
from telethon import events, Button

# ======================
# File database server
# ======================
SERVER_FILE = "servers.json"

# Load server dari file
def load_servers():
    try:
        with open(SERVER_FILE, "r") as f:
            return json.load(f)
    except:
        return []

# Simpan server ke file
def save_servers(servers):
    with open(SERVER_FILE, "w") as f:
        json.dump(servers, f, indent=4)

# ======================
# Fungsi ambil data dari server remote
# ======================
def get_remote_output(host, command):
    try:
        result = subprocess.check_output(f"ssh root@{host} '{command}'", shell=True).decode().strip()
        return result
    except subprocess.CalledProcessError:
        return "Error"

# ======================
# Menu Bot
# ======================
@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline("𝗦𝗦𝗛 𝗪𝗦", "ssh"), Button.inline("𝗩𝗠𝗘𝗦𝗦", "vmess")],
        [Button.inline("𝗧𝗥𝗢𝗝𝗔𝗡", "trojan"), Button.inline("𝗩𝗣𝗦 𝗜𝗡𝗙𝗢", "info")],
        [Button.inline("𝗔𝗗𝗗 𝗦𝗘𝗥𝗩𝗘𝗥", "add_server")],
        [Button.url("𝗚𝗥𝗨𝗣", "https://t.me/jesvpntun")]
    ]

    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.respond("**Akses Ditolak: Anda tidak terdaftar. Untuk daftar beli VPS dan auto script owner** @JesVpnt")
        return

    servers = load_servers()
    if not servers:
        await event.respond("❌ Belum ada server yang ditambahkan.", buttons=inline)
        return

    all_servers_info = ""
    for srv in servers:
        # Ambil data VPS
        namaos = get_remote_output(srv['host'], "cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | cut -d= -f2 | tr -d '\"'")
        ssh_count = get_remote_output(srv['host'], "cat /etc/ssh/.ssh.db | grep '###' | wc -l")
        vms_count = get_remote_output(srv['host'], "cat /etc/xray/config.json | grep '###' | wc -l")
        trj_count = get_remote_output(srv['host'], "cat /etc/trojan/.trojan.db | grep '###' | wc -l")
        vls_count = get_remote_output(srv['host'], "cat /etc/vless/.vless.db | grep '###' | wc -l")
        ipsaya = get_remote_output(srv['host'], "curl -s ipv4.icanhazip.com")
        uptime = get_remote_output(srv['host'], "uptime -p")
        city = get_remote_output(srv['host'], "cat /etc/xray/city")
        ram_usage = get_remote_output(srv['host'], "free -h | grep Mem")
        total_ram = ram_usage.split()[1] if ram_usage != "Error" else "N/A"
        used_ram = ram_usage.split()[2] if ram_usage != "Error" else "N/A"

        # Ping VPS
        try:
            ping = subprocess.check_output(f"ping -c 1 {ipsaya}", shell=True).decode()
            ping_time = ping.split('time=')[1].split(' ms')[0]
        except:
            ping_time = "N/A"

        # Tambahkan info tiap server ke pesan
        all_servers_info += f"""
**≡ {srv['name']} ≡**
🖥️ OS: {namaos}
🌆 City: {city}
🌐 IP: {ipsaya}
⚡ Uptime: {uptime}
⏱️ Ping: {ping_time} ms
💻 RAM: {used_ram} / {total_ram}
🔑 SSH: {ssh_count} | 💻 VMESS: {vms_count} | 🔒 TROJAN: {trj_count} | VLESS: {vls_count}
"""

    # Info user
    user_id = sender.id
    username = sender.username
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Pesan akhir
    msg = f"""
**≡ P G E T U N N E L MULTI SERVER MENU BOT ≡**
📅 Date: {current_datetime}

{all_servers_info}

🧑‍💻 User Profile
👤 User ID: {user_id}
📝 Username: @{username}
"""

    await event.respond(
        message=msg,
        buttons=inline
    )

# ======================
# Tambah Server lewat tombol
# ======================
@bot.on(events.CallbackQuery(data=b'add_server'))
async def add_server(event):
    await event.respond("Kirim nama VPS:")

    # Tunggu reply user
    response = await bot.wait_event(events.NewMessage(from_users=event.sender_id))
    name = response.raw_text.strip()

    await event.respond("Kirim IP/Host VPS:")
    response2 = await bot.wait_event(events.NewMessage(from_users=event.sender_id))
    host = response2.raw_text.strip()

    servers = load_servers()
    servers.append({"name": name, "host": host})
    save_servers(servers)

    await event.respond(f"✅ Server baru ditambahkan: {name} ({host})")