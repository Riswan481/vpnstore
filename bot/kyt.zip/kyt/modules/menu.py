from kyt import *
from datetime import datetime
import subprocess
import json
import re
import ipaddress
from telethon import events, Button

# ======================
# File database server
# ======================
SERVER_FILE = "servers.json"

# Load server dari file
def load_servers():
    try:
        with open(SERVER_FILE, "r") as f:
            return json.load(f)
    except:
        return []

# Simpan server ke file
def save_servers(servers):
    with open(SERVER_FILE, "w") as f:
        json.dump(servers, f, indent=4)

# ======================
# Fungsi ambil data dari server remote
# ======================
def get_remote_output(host, command, password=None):
    try:
        if password:
            result = subprocess.check_output(
                f"sshpass -p '{password}' ssh -o StrictHostKeyChecking=no root@{host} '{command}'",
                shell=True
            ).decode().strip()
        else:
            result = subprocess.check_output(f"ssh root@{host} '{command}'", shell=True).decode().strip()
        return result
    except subprocess.CalledProcessError:
        return "Error"

# ======================
# Menu Bot
# ======================
@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline("𝗦𝗦𝗛 𝗪𝗦", "ssh"), Button.inline("𝗩𝗠𝗘𝗦𝗦", "vmess")],
        [Button.inline("𝗧𝗥𝗢𝗝𝗔𝗡", "trojan"), Button.inline("𝗩𝗣𝗦 𝗜𝗡𝗙𝗢", "info")],
        [Button.inline("𝗔𝗗𝗗 𝗦𝗘𝗥𝗩𝗘𝗥", "add_server")],
        [Button.url("𝗚𝗥𝗨𝗣", "https://t.me/jesvpntun")]
    ]

    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.respond("**Akses Ditolak: Anda tidak terdaftar. Untuk daftar beli VPS dan auto script owner** @JesVpnt")
        return

    servers = load_servers()
    if not servers:
        await event.respond("❌ Belum ada server yang ditambahkan.", buttons=inline)
        return

    all_servers_info = ""
    for srv in servers:
        namaos = get_remote_output(srv['host'], "cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | cut -d= -f2 | tr -d '\"'", srv.get("password"))
        ssh_count = get_remote_output(srv['host'], "cat /etc/ssh/.ssh.db | grep '###' | wc -l", srv.get("password"))
        vms_count = get_remote_output(srv['host'], "cat /etc/xray/config.json | grep '###' | wc -l", srv.get("password"))
        trj_count = get_remote_output(srv['host'], "cat /etc/trojan/.trojan.db | grep '###' | wc -l", srv.get("password"))
        vls_count = get_remote_output(srv['host'], "cat /etc/vless/.vless.db | grep '###' | wc -l", srv.get("password"))
        ipsaya = get_remote_output(srv['host'], "curl -s ipv4.icanhazip.com", srv.get("password"))
        uptime = get_remote_output(srv['host'], "uptime -p", srv.get("password"))
        city = get_remote_output(srv['host'], "cat /etc/xray/city", srv.get("password"))
        ram_usage = get_remote_output(srv['host'], "free -h | grep Mem", srv.get("password"))
        total_ram = ram_usage.split()[1] if ram_usage != "Error" else "N/A"
        used_ram = ram_usage.split()[2] if ram_usage != "Error" else "N/A"

        try:
            ping = subprocess.check_output(f"ping -c 1 {ipsaya}", shell=True).decode()
            ping_time = ping.split('time=')[1].split(' ms')[0]
        except:
            ping_time = "N/A"

        all_servers_info += f"""
**≡ {srv['name']} ≡**
🖥️ OS: {namaos}
🌆 City: {city}
🌐 IP: {ipsaya}
⚡ Uptime: {uptime}
⏱️ Ping: {ping_time} ms
💻 RAM: {used_ram} / {total_ram}
🔑 SSH: {ssh_count} | 💻 VMESS: {vms_count} | 🔒 TROJAN: {trj_count} | VLESS: {vls_count}
"""

    user_id = sender.id
    username = sender.username
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    msg = f"""
**≡ P G E T U N N E L MULTI SERVER MENU BOT ≡**
📅 Date: {current_datetime}

{all_servers_info}

🧑‍💻 User Profile
👤 User ID: {user_id}
📝 Username: @{username}
"""

    await event.respond(
        message=msg,
        buttons=inline
    )

# ======================
# Tambah Server multi-step
# ======================
@bot.on(events.CallbackQuery(data=b'add_server'))
async def add_server(event):
    await event.answer("Kita akan menambahkan server baru ✅", alert=True)
    cancel_btn = Button.inline("❌ Cancel", b"cancel_add_server")

    async with bot.conversation(event.sender_id, timeout=120) as conv:
        # Step 1: Nama VPS
        await conv.send_message("📌 Kirim nama VPS:", buttons=[cancel_btn])
        try:
            name_msg = await conv.get_response()
            name = name_msg.text.strip()
        except:
            await event.respond("❌ Timeout. Silakan coba lagi.")
            return

        # Step 2: IP/Host
        await conv.send_message("📌 Kirim IP/Host VPS:", buttons=[cancel_btn])
        try:
            host_msg = await conv.get_response()
            host = host_msg.text.strip()
            # Validasi IP atau domain
            valid_host = False
            try:
                ipaddress.ip_address(host)
                valid_host = True
            except ValueError:
                if re.match(r'^[a-zA-Z0-9.-]+$', host):
                    valid_host = True
            if not valid_host:
                await event.respond("❌ Format IP/Host tidak valid!")
                return
        except:
            await event.respond("❌ Timeout. Silakan coba lagi.")
            return

        # Step 3: Password
        await conv.send_message("📌 Kirim password VPS:", buttons=[cancel_btn])
        try:
            pw_msg = await conv.get_response()
            password = pw_msg.text.strip()
        except:
            await event.respond("❌ Timeout. Silakan coba lagi.")
            return

        # Simpan server
        servers = load_servers()
        servers.append({"name": name, "host": host, "password": password})
        save_servers(servers)

        await event.respond(f"✅ Server baru berhasil ditambahkan:\n**{name}** ({host})")

# ======================
# Tombol Cancel
# ======================
@bot.on(events.CallbackQuery(data=b'cancel_add_server'))
async def cancel_add(event):
    await event.answer("❌ Penambahan server dibatalkan.", alert=True)