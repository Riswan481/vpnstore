#!/bin/bash

YELLOW="\e[33m"
ENDCOLOR="\e[0m"

clear

echo -e "${YELLOW}================ SSH & OVPN User Info =================${ENDCOLOR}"

# Ambil semua user (uid >= 1000)
allusers=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody)

for user in $allusers; do
    # Tanggal kadaluarsa
    exp=$(chage -l $user 2>/dev/null | grep "Account expires" | cut -d: -f2 | xargs)
    [ -z "$exp" ] && exp="Never expires"

    # Max login dari limits.conf
    maxlogins=$(grep -E "^$user" /etc/security/limits.conf | grep "maxlogins" | awk '{print $4}')
    [ -z "$maxlogins" ] && maxlogins="1"

    # Ambil IP login terakhir sesuai limit
    last_ips=$(last -i $user | grep -v "wtmp" | awk '{print $3}' | head -n $maxlogins)
    [ -z "$last_ips" ] && last_ips="No active login"

    echo -e "${YELLOW}User       : $user${ENDCOLOR}"
    echo -e "${YELLOW}Expires    : $exp${ENDCOLOR}"
    echo -e "${YELLOW}Max Login  : $maxlogins${ENDCOLOR}"
    echo -e "${YELLOW}Last IP(s) :${ENDCOLOR}"
    for ip in $last_ips; do
        echo -e "${YELLOW}  - $ip${ENDCOLOR}"
    done
    echo -e "${YELLOW}----------------------------------------------------${ENDCOLOR}"
done

echo -e "${YELLOW}================= END OF LIST =================${ENDCOLOR}\n"
read -p "Press Enter to return..."; read
menu