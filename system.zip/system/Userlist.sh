#!/bin/bash

# ===== COLORS =====
YELLOW="\e[33m"
RED="\e[31m"
GREEN="\e[32m"
ENDCOLOR="\e[0m"

clear
echo -e "${YELLOW}=============== USER LIST ===============${ENDCOLOR}"

# Ambil semua user (uid >= 1000) kecuali nobody
allusers=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody)

for user in $allusers; do
    exp=$(chage -l "$user" 2>/dev/null | grep "Account expires" | cut -d: -f2 | xargs)

    if [[ "$exp" =~ "Never" || "$exp" =~ "never" ]]; then
        exp_full="Never expires"
        sisa_hari="Unlimited"
    else
        exp_date=$(date -d "$exp" +%Y-%m-%d 2>/dev/null)
        exp_full="$exp_date 23:59:59"

        today_sec=$(date +%s)
        expiry_sec=$(date -d "$exp_date" +%s)
        diff_sec=$(( expiry_sec - today_sec ))
        diff_days=$(( diff_sec / 86400 ))

        if [ $diff_days -lt 0 ]; then
            echo -e "${RED}❌ User $user sudah expired! Menghapus otomatis...${ENDCOLOR}"
            userdel -r "$user" &>/dev/null
            rm -f /etc/security/limits.d/"$user" 2>/dev/null
            continue
        elif [ $diff_days -eq 0 ]; then
            sisa_hari="Malam ini"
        else
            sisa_hari="$diff_days hari lagi"
        fi
    fi

    maxlogins=$(grep -h "^$user" /etc/security/limits.d/* 2>/dev/null | grep "maxlogins" | awk '{print $4}')
    [ -z "$maxlogins" ] && maxlogins="1"

    echo -e "${GREEN}👤 User       : $user${ENDCOLOR}"
    echo -e "📅 Expires    : $exp_full ($sisa_hari)"
    echo -e "🔢 Max Login  : $maxlogins"
    echo -e "${YELLOW}=============== USER LIST ===============${ENDCOLOR}"
done

echo
read -p "Press Enter to return..."