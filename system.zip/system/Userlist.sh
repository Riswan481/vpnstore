#!/bin/bash

# ===== COLORS =====
YELLOW="\e[33m"
RED="\e[31m"
GREEN="\e[32m"
ENDCOLOR="\e[0m"

clear
echo -e "${YELLOW}=============== USER LIST ===============${ENDCOLOR}"

# Ambil semua user (uid >= 1000) kecuali nobody
allusers=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody)

for user in $allusers; do
    # Ambil tanggal expired user
    exp=$(chage -l "$user" 2>/dev/null | grep "Account expires" | cut -d: -f2 | xargs)

    if [[ "$exp" =~ "Never" || "$exp" =~ "never" ]]; then
        exp_full="Never expires"
        sisa_hari="Unlimited"
    else
        exp_date=$(date -d "$exp" +%Y-%m-%d 2>/dev/null)
        exp_full="$exp_date 23:59:59"

        # Hitung sisa hari
        today=$(date +%s)
        exp_epoch=$(date -d "$exp_full" +%s)
        sisa=$(( (exp_epoch - today) / 86400 ))

        if [ $sisa -lt 0 ]; then
            echo -e "${RED}❌ User $user sudah expired! Menghapus otomatis...${ENDCOLOR}"
            userdel -r "$user" &>/dev/null
            rm -f /etc/security/limits.d/"$user" 2>/dev/null
            continue
        else
            if [ $sisa -eq 0 ]; then
                sisa_hari="Malam ini"
            else
                sisa_hari="$sisa hari lagi"
            fi
        fi
    fi

    # Ambil Max Login dari file limits
    maxlogins=$(grep -h "^$user" /etc/security/limits.d/* 2>/dev/null | grep "maxlogins" | awk '{print $4}')
    [ -z "$maxlogins" ] && maxlogins="1"

    # Tampilkan info user
    echo -e "${GREEN}👤 User       : $user${ENDCOLOR}"
    echo -e "📅 Expires    : $exp_full ($sisa_hari)"
    echo -e "🔢 Max Login  : $maxlogins"
    echo -e "${YELLOW}=============== USER LIST ===============${ENDCOLOR}"
done

echo
read -p "Press Enter to return..."