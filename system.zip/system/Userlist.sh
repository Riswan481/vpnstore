#!/bin/bash

# ===== COLORS =====
YELLOW="\e[33m"
RED="\e[31m"
GREEN="\e[32m"
ENDCOLOR="\e[0m"

LOG_FILE="/var/log/expired_users.log"

# Pastikan script punya izin eksekusi
SCRIPT_PATH=$(realpath "$0")
chmod +x "$SCRIPT_PATH"

# Buat log file kalau belum ada
touch $LOG_FILE

echo -e "${YELLOW}=============== CEK USER & AUTO DELETE EXPIRED ===============${ENDCOLOR}"

# Ambil semua user (uid >= 1000) kecuali nobody
allusers=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody)

for user in $allusers; do
    # Ambil tanggal expired user
    exp=$(chage -l "$user" 2>/dev/null | grep "Account expires" | cut -d: -f2 | xargs)

    if [[ "$exp" =~ "Never" || "$exp" =~ "never" ]]; then
        exp_full="Never expires"
        sisa_hari="Unlimited"
    else
        exp_date=$(date -d "$exp" +"%Y-%m-%d" 2>/dev/null)
        exp_full="$exp_date 23:59:59"

        today=$(date +%s)
        exp_epoch=$(date -d "$exp_full" +%s 2>/dev/null)

        [[ -z "$exp_epoch" ]] && continue

        sisa=$(( (exp_epoch - today) / 86400 ))

        # Kalau sudah expired langsung hapus
        if [ $sisa -le 0 ]; then
            echo -e "${RED}❌ User $user expired ($exp_full) → Menghapus otomatis...${ENDCOLOR}"
            echo "$(date '+%Y-%m-%d %H:%M:%S') : $user expired ($exp_full) dihapus" >> $LOG_FILE
            userdel -r "$user" &>/dev/null
            rm -f /etc/security/limits.d/"$user" 2>/dev/null
            continue
        fi

        sisa_hari="$sisa hari lagi"
    fi

    # Ambil Max Login dari file limits
    maxlogins=$(grep -h "^$user" /etc/security/limits.d/* 2>/dev/null | grep "maxlogins" | awk '{print $4}')
    [ -z "$maxlogins" ] && maxlogins="1"

    # Tampilkan info user aktif
    echo -e "${GREEN}👤 User       : $user${ENDCOLOR}"
    echo -e "📅 Expires    : $exp_full ($sisa_hari)"
    echo -e "🔢 Max Login  : $maxlogins"
    echo -e "${YELLOW}-------------------------------------------------------------${ENDCOLOR}"
done

# ========== CRON OTOMATIS ==========
# Cek apakah sudah ada cron job
if ! crontab -l 2>/dev/null | grep -q "$SCRIPT_PATH"; then
    # Jalan setiap 1 jam
    (crontab -l 2>/dev/null; echo "0 * * * * $SCRIPT_PATH >/dev/null 2>&1") | crontab -
    echo -e "${GREEN}✔ Cron job ditambahkan: cek expired setiap 1 jam${ENDCOLOR}"
fi