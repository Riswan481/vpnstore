#!/bin/bash

# ===== WARNA & FORMAT =====
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[93m"
CYAN="\e[36m"
BOLD="\e[1m"
RESET="\e[0m"

# ===== FILE KONFIG & BACKUP =====
HOST_FILE="/root/udp/host.conf"
BACKUP_DIR="/root/udp/backup"
EXP_FILE="/root/udp/expired_users.txt"
mkdir -p /root/udp "$BACKUP_DIR"
[[ ! -f $EXP_FILE ]] && touch $EXP_FILE

# ===== FUNGSI HOST =====
get_host() { [[ -s $HOST_FILE ]] && cat $HOST_FILE || curl -s https://ipecho.net/plain; }
view_host() { 
    local h=$(get_host)
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${GREEN}🌐 Host Aktif : $h${RESET}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
}
set_host() { 
    echo "$1" > $HOST_FILE
    echo -e "${GREEN}✅ Host berhasil diubah: $1${RESET}"
}
reset_host() { 
    rm -f $HOST_FILE
    echo -e "${GREEN}✅ Host direset, kembali ke IP VPS${RESET}"
}

# ===== FUNGSI USER =====
create_user() {
    local username="$1" password="$2" expire_days="$3" maxlogins="$4" s_ip=$(get_host)
    [[ $(id -u $username 2>/dev/null) ]] && { 
        echo -e "${RED}⚠ User sudah ada${RESET}"
        return
    }

    exp_date=$(date -d "+$expire_days days" +%Y-%m-%d)
    useradd -M -N -s /bin/bash "$username" && echo "$username:$password" | chpasswd
    chage -E "$exp_date" "$username"
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username.conf"
    echo "$username:$exp_date" >> $EXP_FILE

    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${GREEN}✅ AKUN BARU UDP PREMIUM${RESET}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "🌐 Host/IP : ${YELLOW}$s_ip${RESET}"
    echo -e "👤 Username : ${YELLOW}$username${RESET}"
    echo -e "🔑 Password : ${YELLOW}$password${RESET}"
    echo -e "⏳ Expired : ${YELLOW}$exp_date${RESET}"
    echo -e "🔒 Max Login : ${YELLOW}$maxlogins${RESET}"
    echo -e "🌐 UDP : ${YELLOW}$s_ip:1-65535@$username:$password${RESET}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
}

create_trial() {
    local s_ip=$(get_host)
    username="trial$(openssl rand -hex 2)"
    while id "$username" &>/dev/null; do username="trial$(openssl rand -hex 3)"; done
    password=$(openssl rand -base64 3)
    maxlogins=20
    exp_date=$(date -d "+1 day" +%Y-%m-%d)

    useradd -M -N -s /bin/bash "$username" && echo "$username:$password" | chpasswd
    chage -E "$exp_date" "$username"
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username.conf"
    echo "$username:$exp_date" >> $EXP_FILE

    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${GREEN}⚡ TRIAL UDP PREMIUM${RESET}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "🌐 Host/IP : ${YELLOW}$s_ip${RESET}"
    echo -e "👤 Username : ${YELLOW}$username${RESET}"
    echo -e "🔑 Password : ${YELLOW}$password${RESET}"
    echo -e "⏳ Expired : ${YELLOW}$exp_date${RESET}"
    echo -e "🔒 Max Login : ${YELLOW}$maxlogins${RESET}"
    echo -e "🌐 UDP : ${YELLOW}$s_ip:1-65535@$username:$password${RESET}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
}

renew_user() {
    read -p "Username: " username
    read -p "Tambah masa aktif (hari): " tambah
    [[ ! $(id -u $username 2>/dev/null) ]] && { echo -e "${RED}❌ User tidak ditemukan${RESET}"; return; }
    exp_lama=$(chage -l $username | grep "Account expires" | awk -F": " '{print $2}')
    [[ "$exp_lama" == "never" ]] && exp_baru=$(date -d "+$tambah days" +%Y-%m-%d) || exp_baru=$(date -d "$exp_lama + $tambah days" +%Y-%m-%d)
    chage -E $exp_baru $username
    sed -i "/^$username:/d" $EXP_FILE
    echo "$username:$exp_baru" >> $EXP_FILE
    echo -e "${GREEN}✅ User $username diperpanjang sampai $exp_baru${RESET}"
}

delete_user() {
    read -p "Username yang ingin dihapus: " username
    [[ ! $(id -u $username 2>/dev/null) ]] && { echo -e "${RED}❌ User tidak ditemukan${RESET}"; return; }
    userdel -r $username 2>/dev/null
    rm -f /etc/security/limits.d/$username.conf
    sed -i "/^$username:/d" $EXP_FILE
    echo -e "${GREEN}✅ User $username berhasil dihapus${RESET}"
}

list_user() {
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${GREEN}📋 Daftar User Aktif${RESET}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    for u in $(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd); do
        exp=$(chage -l "$u" | grep "Account expires" | awk -F": " '{print $2}')
        echo -e "👤 $u : $exp"
    done
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━${RESET}"
}

backup_data() {
    mkdir -p $BACKUP_DIR
    cp $HOST_FILE $BACKUP_DIR/ 2>/dev/null
    cp $EXP_FILE $BACKUP_DIR/ 2>/dev/null
    tar -czf /root/udp/backup_ssh.tar.gz -C /root/udp backup

    # Upload dan simpan link
    LINK=$(curl -s -F "file=@/root/udp/backup_ssh.tar.gz" https://0x0.st)
    
    # Cek apakah LINK kosong
    if [[ -n "$LINK" ]]; then
        echo -e "${GREEN}✅ Backup selesai! Link download: $LINK${RESET}"
    else
        echo -e "${RED}❌ Backup gagal, link tidak muncul${RESET}"
    fi
}

restore_data() {
    read -p "Masukkan link backup: " link
    wget -qO /root/udp/backup_ssh.tar.gz "$link"
    tar -xzf /root/udp/backup_ssh.tar.gz -C /root/udp/
    echo -e "${GREEN}✅ Restore selesai${RESET}"
}

# ===== OTOMATIS HAPUS USER EXPIRED SAAT MENU =====
delete_expired_users() {
    echo -e "${YELLOW}🔍 Mengecek user expired...${RESET}"
    today=$(date +%Y-%m-%d)
    count=0
    [[ ! -f $EXP_FILE ]] && touch $EXP_FILE
    > /tmp/exp_tmp.txt
    while IFS=":" read -r username exp_date; do
        [[ -z "$username" || -z "$exp_date" ]] && continue
        if [[ "$today" > "$exp_date" || "$today" == "$exp_date" ]]; then
            userdel -r "$username" 2>/dev/null
            rm -f /etc/security/limits.d/$username.conf
            echo -e "${RED}⚠ User $username expired ($exp_date) → dihapus otomatis${RESET}"
            ((count++))
        else
            echo "$username:$exp_date" >> /tmp/exp_tmp.txt
        fi
    done < $EXP_FILE
    mv /tmp/exp_tmp.txt $EXP_FILE 2>/dev/null
    echo -e "${GREEN}✅ Total $count user expired dihapus${RESET}"
}

# ===== MENU UTAMA =====
menu() {
    delete_expired_users  # cek dan hapus expired setiap kali menu dibuka
    clear
    echo -e "${YELLOW}╔══════════════════════════════════${RESET}"
    echo -e "${YELLOW}║   🌐 PANEL MANAJEMEN VPS 🌐       ${RESET}"
    echo -e "${YELLOW}╠══════════════════════════════════${RESET}"
    echo -e "${YELLOW}║ 1) Tambah User${RESET}"
    echo -e "${YELLOW}║ 2) Tambah Trial${RESET}"
    echo -e "${YELLOW}║ 3) Perpanjang User${RESET}"
    echo -e "${YELLOW}║ 4) Hapus User${RESET}"
    echo -e "${YELLOW}║ 5) List User Aktif${RESET}"
    echo -e "${YELLOW}║ 6) Host Aktif${RESET}"
    echo -e "${YELLOW}║ 7) Set Host${RESET}"
    echo -e "${YELLOW}║ 8) Reset Host${RESET}"
    echo -e "${YELLOW}║ 9) Backup link${RESET}"
    echo -e "${YELLOW}║ 10) Restore link${RESET}"
    echo -e "${YELLOW}║ 0) Keluar${RESET}"
    echo -e "${YELLOW}╚══════════════════════════════════${RESET}"
    echo ""
    read -p "⚡ Pilih menu [0-10]: " pilih
    case $pilih in
        1) read -p "Username: " u; read -p "Password: " p; read -p "Expired (hari): " e; read -p "Max login: " m; create_user "$u" "$p" "$e" "$m" ;;
        2) create_trial ;;
        3) renew_user ;;
        4) delete_user ;;
        5) list_user ;;
        6) view_host ;;
        7) read -p "Masukkan host/IP: " h; set_host "$h" ;;
        8) reset_host ;;
        9) backup_data ;;
        10) restore_data ;;
        0|"") exit 0 ;;
        *) echo -e "${RED}⚠ Pilihan salah!${RESET}"; sleep 1 ;;
    esac
    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== START SCRIPT =====
SCRIPT_PATH="$(realpath "$0")"
chmod +x "$SCRIPT_PATH"

menu