#!/bin/bash

# ===== COLORS =====
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
ENDCOLOR="\e[0m"

HOST_FILE="/root/udp/host.conf"

# ===== FUNGSI AMBIL HOST/IP =====
get_host() {
    if [[ -s $HOST_FILE ]]; then
        cat $HOST_FILE
    else
        wget -4 -qO- https://ipecho.net/plain
    fi
}

# ===== FUNGSI TAMBAH USER BIASA =====
add_user() {
    s_ip=$(get_host)

    clear
    echo -ne "${YELLOW}Masukkan username: ${ENDCOLOR}"; read username

    if id "$username" &>/dev/null; then
        echo -e "${RED}User $username sudah ada${ENDCOLOR}"
        sleep 2
        menu
    fi

    echo -ne "Masukkan password: "; read password
    echo -e "${GREEN}Password set successfully!${ENDCOLOR}"

    echo -ne "Masukkan expired (hari): "; read masaaktif

    # Format tanggal expired (WIB)
    expe=$(TZ="Asia/Jakarta" date -d "$masaaktif days" +"%d %b, %Y (%H:%M)")
    tnggl=$(TZ="Asia/Jakarta" date +"%d %b, %Y (%H:%M)")

    read -p "Max logins limit: " maxlogins
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username"

    # Buat user dengan expired (pakai jam server untuk sistem)
    useradd -e $(date -d "$masaaktif days" +"%Y-%m-%d") -M -N -s /bin/bash $username
    echo -e "$password\n$password\n" | passwd $username &>/dev/null

    clear
    echo -e "${YELLOW}User created successfully!${ENDCOLOR}"
    sleep 1
    clear

    echo -e "\
================================
        ⚡ SSH & OVPN Account ⚡
================================
🌐 Host/IP         : $s_ip
👤 Username     : $username
🔑 Password     : $password
📆 Dibuat            : $tnggl
⏳Expired           : $expe
📄 Aktif               : ( $masaaktif hari )
🔒 Max Login     : $maxlogins Login
================================
🚀 Http Custom UDP
🌐 $s_ip:1-65535@$username:$password
================================
📱 Telegram : t.me/JesVpnt
📞 WhatsApp : wa.me/6285888801241
================================
"

    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== FUNGSI TAMBAH TRIAL USER RANDOM 5 MENIT =====
add_trial_auto_delete() {
    s_ip=$(get_host)  # Ambil host/IP server

    clear
    # Generate username trial unik
    username="trial$(openssl rand -hex 1)"
    while id "$username" &>/dev/null; do
        username="trial$(openssl rand -hex 3)"
    done

    # Generate password random
    password=$(openssl rand -base64 6)

    maxlogins=1
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username"

    # Tambah user trial tanpa home directory
    if useradd -M -N -s /bin/bash "$username"; then
        echo -e "$password\n$password\n" | passwd "$username" &>/dev/null
    else
        echo -e "${RED}Gagal membuat user $username${ENDCOLOR}"
        sleep 2
        return
    fi

    # Pastikan atd aktif
    if ! systemctl is-active --quiet atd; then
        systemctl start atd
        systemctl enable atd
    fi

    # Hapus otomatis 5 menit dari sekarang
    echo "userdel -r $username 2>/dev/null" | at now + 5 minutes

    # Format tanggal WIB
    tnggl=$(TZ="Asia/Jakarta" date +"%d %b, %Y (%H:%M)")
    exp_date=$(TZ="Asia/Jakarta" date -d "+5 minutes" +"%d %b, %Y (%H:%M)")

    clear
    echo -e "${GREEN}Trial user created successfully!${ENDCOLOR}"
    sleep 1
    clear

    echo -e "\
================================
     ⚡ SSH & OVPN Trial Account ⚡
================================
🌐 Host/IP: $s_ip
👤 Username: $username
🔑 Password: $password
📆 Dibuat: $tnggl
⏳ Expired: $exp_date
🔒 Max Login: $maxlogins
================================
🚀 Http Custom UDP
$s_ip:1-65535@$username:$password
================================
"

    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== FUNGSI TAMBAH HOST =====
add_host() {
    clear
    echo -ne "${YELLOW}Masukkan IP/Host baru: ${ENDCOLOR}"; read host
    echo "$host" > $HOST_FILE
    echo -e "${GREEN}Host berhasil disimpan: $host${ENDCOLOR}"
    sleep 2
    menu
}

# ===== FUNGSI RESET HOST =====
reset_host() {
    clear
    if [[ -f $HOST_FILE ]]; then
        rm -f $HOST_FILE
        echo -e "${GREEN}Host berhasil direset, kembali ke IP VPS.${ENDCOLOR}"
    else
        echo -e "${YELLOW}Belum ada host custom yang diset.${ENDCOLOR}"
    fi
    sleep 2
    menu
}

# ===== FUNGSI LIHAT HOST AKTIF =====
view_host() {
    clear
    current=$(get_host)
    echo -e "${CYAN}Host/IP yang aktif sekarang:${ENDCOLOR}"
    echo -e "${GREEN}$current${ENDCOLOR}"
    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== FUNGSI BACKUP DATA KE LINK =====
backup_data() {
    clear
    BACKUP_DIR="/root/udp/backup"
    mkdir -p $BACKUP_DIR

    awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd > $BACKUP_DIR/users.list

    > $BACKUP_DIR/shadow.backup
    for u in $(cat $BACKUP_DIR/users.list); do
        chage -l $u | grep "Account expires" | awk -F": " '{print $2}' > $BACKUP_DIR/$u.expire
        grep "^$u:" /etc/shadow >> $BACKUP_DIR/shadow.backup
    done

    if [[ -f $HOST_FILE ]]; then
        cp $HOST_FILE $BACKUP_DIR/
    fi

    tar -czf /root/udp/backup_ssh.tar.gz -C /root/udp backup

    LINK=$(curl -s -F "file=@/root/udp/backup_ssh.tar.gz" https://0x0.st)
    echo -e "${GREEN}Backup sukses! Simpan link ini:${ENDCOLOR}"
    echo -e "${CYAN}$LINK${ENDCOLOR}"
    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== FUNGSI RESTORE DATA DARI LINK =====
restore_data() {
    clear
    echo -ne "${YELLOW}Masukkan link backup: ${ENDCOLOR}"; read link

    mkdir -p /root/udp
    wget -qO /root/udp/backup_ssh.tar.gz "$link"

    if [[ ! -f /root/udp/backup_ssh.tar.gz ]]; then
        echo -e "${RED}Gagal download backup dari link!${ENDCOLOR}"
        sleep 2
        menu
    fi

    tar -xzf /root/udp/backup_ssh.tar.gz -C /root/udp/
    cd /root/udp/backup

    # Jangan timpa full /etc/shadow, restore per-user saja
    for u in $(cat users.list); do
        if ! id "$u" &>/dev/null; then
            useradd -M -N -s /bin/bash "$u"
        fi

        shadow_line=$(grep "^$u:" shadow.backup)
        if [[ -n "$shadow_line" ]]; then
            sed -i "/^$u:/d" /etc/shadow
            echo "$shadow_line" >> /etc/shadow
        fi

        expire=$(cat $u.expire)
        if [[ $expire != "never" ]]; then
            expire_date=$(date -d "$expire" +%Y-%m-%d)
            chage -E $expire_date $u
        fi
    done

    if [[ -f host.conf ]]; then
        cp host.conf $HOST_FILE
    fi

    echo -e "${GREEN}Restore sukses dari link $link${ENDCOLOR}"
    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== FUNGSI LIST USER =====
list_user() {
    clear
    echo -e "${CYAN}Daftar User SSH Aktif:${ENDCOLOR}"
    echo "=========================================="
    printf "%-15s %-20s\n" "Username" "Expired Date"
    echo "------------------------------------------"
    total=0
    for u in $(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd); do
        exp=$(chage -l $u | grep "Account expires" | awk -F": " '{print $2}')
        printf "%-15s %-20s\n" "$u" "$exp"
        ((total++))
    done
    echo "------------------------------------------"
    echo -e "Total User Aktif : ${GREEN}$total${ENDCOLOR}"
    echo "=========================================="
    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== AUTO HAPUS USER EXPIRED (untuk cron) =====
auto_expired() {
    LOG_FILE="/var/log/expired_users.log"
    mkdir -p /var/log
    > $LOG_FILE

    for user in $(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd); do
        exp_date=$(chage -l $user | grep "Account expires" | awk -F": " '{print $2}')
        if [[ "$exp_date" != "never" && "$exp_date" != "Account expires" ]]; then
            exp_sec=$(date -d "$exp_date" +%s)
            now_sec=$(date +%s)
            if [[ $exp_sec -lt $now_sec ]]; then
                echo "$(date) : $user expired ($exp_date) → dihapus" >> $LOG_FILE
                userdel -r $user 2>/dev/null
            fi
        fi
    done
}

# ===== FUNGSI MENU =====
menu() {
    clear
    echo -e "${YELLOW}╔══════════════════════════════════${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR}   ${YELLOW}🌐 PANEL MANAJEMEN VPS 🌐         ${ENDCOLOR}"
    echo -e "${YELLOW}╠══════════════════════════════════${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}1) ➤ Tambah User         ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}2) ➤ Tambah Trial        ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}3) ➤ Tambah Host         ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}4) ➤ Reset Host          ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}5) ➤ Host Aktif          ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}6) ➤ Backup (Link)       ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}7) ➤ Restore (Link)      ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}8) ➤ List User Aktif     ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}0) ➤ Keluar              ${ENDCOLOR}"
    echo -e "${YELLOW}╚══════════════════════════════════${ENDCOLOR}"
    echo ""
    read -p "⚡ Pilih menu [0-8]: " pilih

    case $pilih in
        1) add_user ;;
        2) add_trial ;;
        3) add_host ;;
        4) reset_host ;;
        5) view_host ;;
        6) backup_data ;;
        7) restore_data ;;
        8) list_user ;;
        0|"") exit 0 ;;
        *) echo -e "${RED}⚠ Pilihan salah!${ENDCOLOR}"; sleep 1; menu ;;
    esac
}

# ===== START SCRIPT =====
if [[ "$1" == "expired" ]]; then
    auto_expired
    exit 0
else
    menu
fi