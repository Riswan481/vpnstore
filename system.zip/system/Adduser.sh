#!/bin/bash

# ===== COLORS =====
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
ENDCOLOR="\e[0m"

HOST_FILE="/root/udp/host.conf"
CONFIG_FILE="/root/udp/bot.conf"
TMP_CMD="/tmp/tg_cmd.txt"

# ===== FUNGSI LOAD KONFIG BOT =====
load_bot_config() {
    if [[ -f $CONFIG_FILE ]]; then
        source $CONFIG_FILE
    else
        BOT_TOKEN=""
        CHAT_ID=""
    fi
}

# ===== FUNGSI SEND MESSAGE =====
tg_send() {
    local text="$1"
    if [[ -n "$BOT_TOKEN" && -n "$CHAT_ID" ]]; then
        curl -s -X POST "https://api.telegram.org/bot$BOT_TOKEN/sendMessage" \
             -d chat_id="$CHAT_ID" \
             -d parse_mode="HTML" \
             -d text="$text" > /dev/null
    fi
}

# ===== FUNGSI AMBIL HOST/IP =====
get_host() {
    if [[ -s $HOST_FILE ]]; then
        cat $HOST_FILE
    else
        wget -4 -qO- https://ipecho.net/plain
    fi
}

# ===== FUNGSI USER BIASA =====
add_user() {
    s_ip=$(get_host)
    if [[ -z "$1" ]]; then
        clear
        echo -ne "${YELLOW}Masukkan username: ${ENDCOLOR}"; read username
        echo -ne "Masukkan password: "; read password
        echo -ne "Masukkan expired (hari): "; read expire_days
        read -p "Max logins limit: " maxlogins
    else
        username="$1"
        password="$2"
        expire_days="$3"
        maxlogins="$4"
    fi

    if id "$username" &>/dev/null; then
        tg_send "<b>Error:</b> User $username sudah ada!"
        [[ -z "$1" ]] && echo -e "${RED}User sudah ada!${ENDCOLOR}" && sleep 2 && menu
        return
    fi

    useradd -M -N -s /bin/bash $username && echo "$username:$password" | chpasswd
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username"

    if [[ $expire_days -eq 1 ]]; then
        expire_date=$(date -d "today" +%Y-%m-%d)
        expire_full=$(date -d "today 23:59:59" "+%Y-%m-%d %H:%M:%S")
    else
        expire_date=$(date -d "$((expire_days-1)) days" +%Y-%m-%d)
        expire_full=$(date -d "$((expire_days-1)) days 23:59:59" "+%Y-%m-%d %H:%M:%S")
    fi

    chage -E $expire_date $username

    if ! systemctl is-active --quiet atd; then
        systemctl start atd
        systemctl enable atd
    fi
    echo "userdel -r $username 2>/dev/null" | at "$expire_full"

    msg="🌐 Host/IP: $s_ip
👤 Username: $username
🔑 Password: $password
⏳ Expired: $expire_full
🔒 Max Login: $maxlogins"
    tg_send "<b>User created:</b>\n$msg"

    [[ -z "$1" ]] && echo -e "${GREEN}User berhasil dibuat!${ENDCOLOR}" && sleep 1 && menu
}

# ===== FUNGSI TRIAL =====
add_trial() {
    s_ip=$(get_host)
    username="trial$(openssl rand -hex 1)"
    while id "$username" &>/dev/null; do
        username="trial$(openssl rand -hex 3)"
    done
    password=$(openssl rand -base64 3)
    maxlogins=1

    useradd -M -N -s /bin/bash $username && echo "$username:$password" | chpasswd
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username"
    chage -E $(date -d "+1 hour" +%Y-%m-%d) $username

    if ! systemctl is-active --quiet atd; then
        systemctl start atd
        systemctl enable atd
    fi
    echo "userdel -r $username 2>/dev/null" | at now + 1 hour

    msg="🌐 Host/IP: $s_ip
👤 Username: $username
🔑 Password: $password
⏳ Expired: 1 jam
🔒 Max Login: $maxlogins"
    tg_send "<b>Trial user created:</b>\n$msg"

    echo -e "${GREEN}Trial user berhasil dibuat!${ENDCOLOR}" && sleep 1 && menu
}

# ===== FUNGSI HOST =====
add_host() {
    host="$1"
    if [[ -z "$host" ]]; then
        clear
        echo -ne "${YELLOW}Masukkan IP/Host baru: ${ENDCOLOR}"; read host
    fi
    echo "$host" > $HOST_FILE
    tg_send "<b>Host berhasil disimpan:</b> $host"
    [[ -z "$1" ]] && echo -e "${GREEN}Host berhasil disimpan!${ENDCOLOR}" && sleep 2 && menu
}

reset_host() {
    if [[ -f $HOST_FILE ]]; then
        rm -f $HOST_FILE
        tg_send "<b>Host berhasil direset, kembali ke IP VPS</b>"
    else
        tg_send "<b>Belum ada host custom yang diset</b>"
    fi
    [[ -z "$1" ]] && sleep 2 && menu
}

view_host() {
    current=$(get_host)
    tg_send "<b>Host/IP aktif:</b>\n$current"
    [[ -z "$1" ]] && echo -e "${CYAN}Host/IP aktif: ${current}${ENDCOLOR}" && read -p "Tekan Enter" && menu
}

# ===== BACKUP / RESTORE =====
backup_data() {
    BACKUP_DIR="/root/udp/backup"
    mkdir -p $BACKUP_DIR
    awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd > $BACKUP_DIR/users.list
    > $BACKUP_DIR/shadow.backup
    for u in $(cat $BACKUP_DIR/users.list); do
        chage -l $u | grep "Account expires" | awk -F": " '{print $2}' > $BACKUP_DIR/$u.expire
        grep "^$u:" /etc/shadow >> $BACKUP_DIR/shadow.backup
    done
    [[ -f $HOST_FILE ]] && cp $HOST_FILE $BACKUP_DIR/
    tar -czf /root/udp/backup_ssh.tar.gz -C /root/udp backup
    LINK=$(curl -s -F "file=@/root/udp/backup_ssh.tar.gz" https://0x0.st)
    tg_send "<b>Backup sukses! Simpan link ini:</b>\n$LINK"
    [[ -z "$1" ]] && echo -e "${GREEN}Backup sukses! Link: $LINK${ENDCOLOR}" && read -p "Enter" && menu
}

restore_data() {
    link="$1"
    if [[ -z "$link" ]]; then
        clear
        echo -ne "${YELLOW}Masukkan link backup: ${ENDCOLOR}"; read link
    fi
    mkdir -p /root/udp
    wget -qO /root/udp/backup_ssh.tar.gz "$link"
    if [[ ! -f /root/udp/backup_ssh.tar.gz ]]; then
        tg_send "<b>Gagal download backup dari link!</b>"
        [[ -z "$1" ]] && sleep 2 && menu
        return
    fi
    tar -xzf /root/udp/backup_ssh.tar.gz -C /root/udp/
    cd /root/udp/backup
    for u in $(cat users.list); do
        if ! id "$u" &>/dev/null; then
            useradd -M -N -s /bin/bash "$u"
        fi
        shadow_line=$(grep "^$u:" shadow.backup)
        [[ -n "$shadow_line" ]] && sed -i "/^$u:/d" /etc/shadow && echo "$shadow_line" >> /etc/shadow
        expire=$(cat $u.expire)
        [[ $expire != "never" ]] && expire_date=$(date -d "$expire" +%Y-%m-%d) && chage -E $expire_date $u
    done
    [[ -f host.conf ]] && cp host.conf $HOST_FILE
    tg_send "<b>Restore sukses dari link:</b> $link"
    [[ -z "$1" ]] && echo -e "${GREEN}Restore sukses!${ENDCOLOR}" && read -p "Enter" && menu
}

# ===== SET BOT TOKEN & CHAT ID =====
set_bot() {
    clear
    echo -ne "${YELLOW}Masukkan BOT TOKEN: ${ENDCOLOR}"; read BOT_TOKEN
    echo -ne "${YELLOW}Masukkan CHAT ID: ${ENDCOLOR}"; read CHAT_ID
    mkdir -p /root/udp
    echo "BOT_TOKEN=$BOT_TOKEN" > $CONFIG_FILE
    echo "CHAT_ID=$CHAT_ID" >> $CONFIG_FILE
    tg_send "✅ Bot token dan Chat ID berhasil disimpan!"
    sleep 2
    menu
}

# ===== MENU =====
menu() {
    clear
    echo -e "${YELLOW}╔══════════════════════════════════${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR}   ${YELLOW}🌐 PANEL MANAJEMEN VPS 🌐         ${ENDCOLOR}"
    echo -e "${YELLOW}╠══════════════════════════════════${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}1) ➤ Tambah User         ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}2) ➤ Tambah Trial        ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}3) ➤ Tambah Host         ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}4) ➤ Reset Host          ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}5) ➤ Host Aktif          ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}6) ➤ Backup (Link)       ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}7) ➤ Restore (Link)      ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}8) ➤ Set Bot Token/ID    ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${RED}9) ➤ Keluar              ${ENDCOLOR}"
    echo -e "${YELLOW}╚══════════════════════════════════${ENDCOLOR}"
    echo ""
    read -p "⚡ Pilih menu [1-9]: " pilih

    case $pilih in
        1) add_user ;;
        2) add_trial ;;
        3) add_host ;;
        4) reset_host ;;
        5) view_host ;;
        6) backup_data ;;
        7) restore_data ;;
        8) set_bot ;;
        9|"") exit 0 ;;
        *) echo -e "${RED}⚠ Pilihan salah!${ENDCOLOR}"; sleep 1; menu ;;
    esac
}

# ===== BOT TELEGRAM POLLING =====
telegram_polling() {
    while true; do
        updates=$(curl -s "https://api.telegram.org/bot$BOT_TOKEN/getUpdates?offset=-1")
        cmds=$(echo "$updates" | jq -r '.result[].message.text')
        for cmd in $cmds; do
            case $cmd in
                /add_user*) params=($cmd); add_user "${params[1]}" "${params[2]}" "${params[3]}" "${params[4]}" ;;
                /add_trial) add_trial ;;
                /add_host*) params=($cmd); add_host "${params[1]}" ;;
                /reset_host) reset_host 1 ;;
                /view_host) view_host 1 ;;
                /backup) backup_data 1 ;;
                /restore*) params=($cmd); restore_data "${params[1]}" ;;
                /menu) tg_send "📋 Perintah:\n/add_user username pass hari maxlogin\n/add_trial\n/add_host host\n/reset_host\n/view_host\n/backup\n/restore link" ;;
            esac
        done
        sleep 5
    done
}

# ===== START SCRIPT =====
load_bot_config
menu &         # Jalankan menu di background
[[ -n "$BOT_TOKEN" && -n "$CHAT_ID" ]] && telegram_polling &

wait