#!/bin/bash

# ===== COLORS =====
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
ENDCOLOR="\e[0m"

HOST_FILE="/root/udp/host.conf"

# ===== FUNGSI AMBIL HOST/IP =====
get_host() {
    if [[ -s $HOST_FILE ]]; then
        cat $HOST_FILE
    else
        wget -4 -qO- https://ipecho.net/plain
    fi
}

# ===== FUNGSI TAMBAH USER BIASA =====
add_user() {
    s_ip=$(get_host)

    clear
    echo -ne "${YELLOW}Masukkan username: ${ENDCOLOR}"; read username

    if id "$username" &>/dev/null; then
        echo -e "${RED}User $username sudah ada${ENDCOLOR}"
        sleep 2
        menu
    fi

    echo -ne "Masukkan password: "; read password
    echo -e "${GREEN}Password set successfully!${ENDCOLOR}"

    echo -ne "Masukkan expired (hari): "; read expire_days
    expire_date=$(date -d "$expire_days days" +%Y-%m-%d)
    expire_full=$(date -d "$expire_days days 23:59:59" "+%Y-%m-%d %H:%M:%S")

    read -p "Max logins limit: " maxlogins
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username"

    # Buat user
    useradd -M -N -s /bin/bash $username && echo "$username:$password" | chpasswd

    # Set expired
    chage -E $expire_date $username

    # ===== AUTO HAPUS USER SAAT EXPIRED =====
    if ! systemctl is-active --quiet atd; then
        systemctl start atd
        systemctl enable atd
    fi
    echo "userdel -r $username 2>/dev/null" | at "$expire_full"

    clear
    echo -e "${YELLOW}User created successfully!${ENDCOLOR}"
    sleep 1
    clear

    echo -e "\
⚡ SSH & OVPN Account ⚡
========================
🌐 Host/IP    : $s_ip
👤 Username   : $username
🔑 Password   : $password
⏳ Expire     : $expire_full  ( $expire_days hari )
🔒 Max Login  : $maxlogins
========================
🚀 Http Custom UDP
$s_ip:1-65535@$username:$password
========================
📱 Telegram : @JesVpnt
📞 WhatsApp : 6285888801241
========================
"

    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== FUNGSI TAMBAH TRIAL USER RANDOM =====
add_trial() {
    s_ip=$(get_host)

    clear
    username="trial$(openssl rand -hex 3)"
    while id "$username" &>/dev/null; do
        username="trial$(openssl rand -hex 3)"
    done

    password=$(openssl rand -base64 12)
    echo -e "${GREEN}Password set successfully!${ENDCOLOR}"

    maxlogins=1
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username"

    useradd -M -N -s /bin/bash $username && echo "$username:$password" | chpasswd

    chage -E $(date -d "+1 hour" +%Y-%m-%d) $username

    if ! systemctl is-active --quiet atd; then
        systemctl start atd
        systemctl enable atd
    fi

    echo "userdel -r $username 2>/dev/null" | at now + 1 hour

    clear
    echo -e "${YELLOW}Trial user created successfully!${ENDCOLOR}"
    sleep 1
    clear

    echo -e "\
⚡ SSH & OVPN Trial Account ⚡
==============================
🌐 Host/IP    : $s_ip
👤 Username   : $username
🔑 Password   : $password
⏳ Expire     : 1 jam
🔒 Max Login  : $maxlogins
==============================
🚀 Http Custom UDP
$s_ip:1-65535@$username:$password
==============================
"

    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== FUNGSI TAMBAH HOST =====
add_host() {
    clear
    echo -ne "${YELLOW}Masukkan IP/Host baru: ${ENDCOLOR}"; read host
    echo "$host" > $HOST_FILE
    echo -e "${GREEN}Host berhasil disimpan: $host${ENDCOLOR}"
    sleep 2
    menu
}

# ===== FUNGSI RESET HOST =====
reset_host() {
    clear
    if [[ -f $HOST_FILE ]]; then
        rm -f $HOST_FILE
        echo -e "${GREEN}Host berhasil direset, kembali ke IP VPS.${ENDCOLOR}"
    else
        echo -e "${YELLOW}Belum ada host custom yang diset.${ENDCOLOR}"
    fi
    sleep 2
    menu
}

# ===== FUNGSI LIHAT HOST AKTIF =====
view_host() {
    clear
    current=$(get_host)
    echo -e "${CYAN}Host/IP yang aktif sekarang:${ENDCOLOR}"
    echo -e "${GREEN}$current${ENDCOLOR}"
    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== FUNGSI BACKUP DATA =====
backup_data() {
    clear
    BACKUP_DIR="/root/udp/backup"
    mkdir -p $BACKUP_DIR

    # Simpan daftar user custom (exclude user system)
    awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd > $BACKUP_DIR/users.list

    # Simpan password hash + expired
    > $BACKUP_DIR/shadow.backup
    for u in $(cat $BACKUP_DIR/users.list); do
        chage -l $u | grep "Account expires" | awk -F": " '{print $2}' > $BACKUP_DIR/$u.expire
        grep "^$u:" /etc/shadow >> $BACKUP_DIR/shadow.backup
    done

    # Backup host.conf
    if [[ -f $HOST_FILE ]]; then
        cp $HOST_FILE $BACKUP_DIR/
    fi

    tar -czf /root/udp/backup_ssh_$(date +%Y%m%d).tar.gz -C /root/udp backup
    echo -e "${GREEN}Backup selesai! File tersimpan di /root/udp/backup_ssh_$(date +%Y%m%d).tar.gz${ENDCOLOR}"
    sleep 2
    menu
}

# ===== FUNGSI RESTORE DATA =====
restore_data() {
    clear
    echo -ne "${YELLOW}Masukkan path file backup (.tar.gz): ${ENDCOLOR}"; read backupfile
    if [[ ! -f $backupfile ]]; then
        echo -e "${RED}File tidak ditemukan!${ENDCOLOR}"
        sleep 2
        menu
    fi

    tar -xzf $backupfile -C /root/udp/
    cd /root/udp/backup

    # Restore shadow (password)
    cp shadow.backup /etc/shadow

    # Restore expired date
    for u in $(cat users.list); do
        expire=$(cat $u.expire)
        if [[ $expire != "never" ]]; then
            expire_date=$(date -d "$expire" +%Y-%m-%d)
            chage -E $expire_date $u
        fi
    done

    # Restore host
    if [[ -f host.conf ]]; then
        cp host.conf $HOST_FILE
    fi

    echo -e "${GREEN}Restore selesai!${ENDCOLOR}"
    sleep 2
    menu
}

# ===== FUNGSI MENU =====
menu() {
    clear
    echo -e "${YELLOW}╔══════════════════════════════════${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR}   ${YELLOW}🌐 PANEL MANAJEMEN VPS 🌐         ${ENDCOLOR}"
    echo -e "${YELLOW}╠══════════════════════════════════${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}1) ➤ Tambah User         ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}2) ➤ Tambah Trial        ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}3) ➤ Tambah Host         ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}4) ➤ Reset Host          ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}5) ➤ Host Aktif          ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}6) ➤ Backup Data         ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}7) ➤ Restore Data        ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${RED}8) ➤ Keluar              ${ENDCOLOR}"
    echo -e "${YELLOW}╚══════════════════════════════════${ENDCOLOR}"
    echo ""
    read -p "⚡ Pilih menu [1-8]: " pilih

    case $pilih in
        1) add_user ;;
        2) add_trial ;;
        3) add_host ;;
        4) reset_host ;;
        5) view_host ;;
        6) backup_data ;;
        7) restore_data ;;
        8|"") exit 0 ;;
        *) echo -e "${RED}⚠ Pilihan salah!${ENDCOLOR}"; sleep 1; menu ;;
    esac
}

# ===== START SCRIPT =====
menu