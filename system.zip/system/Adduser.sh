#!/bin/bash

# ===== COLORS =====
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
ENDCOLOR="\e[0m"

HOST_FILE="/root/udp/host.conf"

# ===== FUNGSI AMBIL HOST/IP =====
get_host() {
    if [[ -s $HOST_FILE ]]; then
        cat $HOST_FILE
    else
        wget -4 -qO- https://ipecho.net/plain
    fi
}

# ===== FUNGSI TAMBAH USER BIASA =====
add_user() {
    s_ip=$(get_host)

    clear
    echo -ne "${YELLOW}Masukkan username: ${ENDCOLOR}"; read username

    # Cek apakah user sudah ada
    if id "$username" &>/dev/null; then
        echo -e "${RED}User $username sudah ada${ENDCOLOR}"
        sleep 2
        menu
    fi

    # Password
    echo -ne "Masukkan password: "; read password
    echo -e "${GREEN}Password set successfully!${ENDCOLOR}"

    # Expired
    echo -ne "Masukkan expired (hari): "; read expire_days

    # Kalau input 1 → expired hari ini jam 23:59:59
    # Kalau lebih → expired di (hari ini + expire_days) jam 23:59:59
    if [[ $expire_days -eq 1 ]]; then
        expire_date=$(date -d "today" +%Y-%m-%d)
        expire_full=$(date -d "today 23:59:59" "+%Y-%m-%d %H:%M:%S")
    else
        expire_date=$(date -d "$expire_days days" +%Y-%m-%d)
        expire_full=$(date -d "$expire_days days 23:59:59" "+%Y-%m-%d %H:%M:%S")
    fi

    # Max login limit
    read -p "Max logins limit: " maxlogins
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username"

    # Tambah user
    useradd -M -N -s /bin/bash $username && echo "$username:$password" | chpasswd

    # Set expired di sistem
    chage -E $expire_date $username

    # Pastikan atd aktif
    if ! systemctl is-active --quiet atd; then
        systemctl start atd
        systemctl enable atd
    fi

    # Auto hapus user tepat jam expired
    echo "userdel -r $username 2>/dev/null" | at "$expire_full"

    clear
    echo -e "${YELLOW}User created successfully!${ENDCOLOR}"
    sleep 1
    clear

    # Info akun
    echo -e "\
================================
       ⚡ SSH & OVPN Account ⚡
================================
🌐 Host/IP    : $s_ip
👤 Username   : $username
🔑 Password   : $password
⏳Expired     : $expire_full
📄 Aktif      : ( $expire_days hari )
🔒 Max Login  : $maxlogins
================================
🚀 Http Custom UDP
🌐 $s_ip:1-65535@$username:$password
================================
📱 Telegram : t.me/JesVpnt
📞 WhatsApp : wa.me/6285888801241
================================
"

    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== FUNGSI TAMBAH TRIAL USER RANDOM =====
add_trial() {
    s_ip=$(get_host)

    clear
    username="trial$(openssl rand -hex 1)"
    while id "$username" &>/dev/null; do
        username="trial$(openssl rand -hex 3)"
    done

    password=$(openssl rand -base64 3)
    echo -e "${GREEN}Password set successfully!${ENDCOLOR}"

    maxlogins=1
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username"

    useradd -M -N -s /bin/bash $username && echo "$username:$password" | chpasswd
    chage -E $(date -d "+1 hour" +%Y-%m-%d) $username

    if ! systemctl is-active --quiet atd; then
        systemctl start atd
        systemctl enable atd
    fi

    echo "userdel -r $username 2>/dev/null" | at now + 1 hour

    clear
    echo -e "${YELLOW}Trial user created successfully!${ENDCOLOR}"
    sleep 1
    clear

    echo -e "\
⚡ SSH & OVPN Trial Account ⚡
======================================
🌐 Host/IP    : $s_ip
👤 Username   : $username
🔑 Password   : $password
⏳Expired     : 1 jam
🔒 Max Login  : $maxlogins
======================================
🚀 Http Custom UDP
$s_ip:1-65535@$username:$password
======================================
"

    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== FUNGSI TAMBAH HOST =====
add_host() {
    clear
    echo -ne "${YELLOW}Masukkan IP/Host baru: ${ENDCOLOR}"; read host
    echo "$host" > $HOST_FILE
    echo -e "${GREEN}Host berhasil disimpan: $host${ENDCOLOR}"
    sleep 2
    menu
}

# ===== FUNGSI RESET HOST =====
reset_host() {
    clear
    if [[ -f $HOST_FILE ]]; then
        rm -f $HOST_FILE
        echo -e "${GREEN}Host berhasil direset, kembali ke IP VPS.${ENDCOLOR}"
    else
        echo -e "${YELLOW}Belum ada host custom yang diset.${ENDCOLOR}"
    fi
    sleep 2
    menu
}

# ===== FUNGSI LIHAT HOST AKTIF =====
view_host() {
    clear
    current=$(get_host)
    echo -e "${CYAN}Host/IP yang aktif sekarang:${ENDCOLOR}"
    echo -e "${GREEN}$current${ENDCOLOR}"
    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== FUNGSI BACKUP DATA KE LINK =====
backup_data() {
    clear
    BACKUP_DIR="/root/udp/backup"
    mkdir -p $BACKUP_DIR

    awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd > $BACKUP_DIR/users.list

    > $BACKUP_DIR/shadow.backup
    for u in $(cat $BACKUP_DIR/users.list); do
        chage -l $u | grep "Account expires" | awk -F": " '{print $2}' > $BACKUP_DIR/$u.expire
        grep "^$u:" /etc/shadow >> $BACKUP_DIR/shadow.backup
    done

    if [[ -f $HOST_FILE ]]; then
        cp $HOST_FILE $BACKUP_DIR/
    fi

    tar -czf /root/udp/backup_ssh.tar.gz -C /root/udp backup

    LINK=$(curl -s -F "file=@/root/udp/backup_ssh.tar.gz" https://0x0.st)
    echo -e "${GREEN}Backup sukses! Simpan link ini:${ENDCOLOR}"
    echo -e "${CYAN}$LINK${ENDCOLOR}"
    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== FUNGSI RESTORE DATA DARI LINK =====
restore_data() {
    clear
    echo -ne "${YELLOW}Masukkan link backup: ${ENDCOLOR}"; read link

    mkdir -p /root/udp
    wget -qO /root/udp/backup_ssh.tar.gz "$link"

    if [[ ! -f /root/udp/backup_ssh.tar.gz ]]; then
        echo -e "${RED}Gagal download backup dari link!${ENDCOLOR}"
        sleep 2
        menu
    fi

    tar -xzf /root/udp/backup_ssh.tar.gz -C /root/udp/
    cd /root/udp/backup

    # Jangan timpa full /etc/shadow, restore per-user saja
    for u in $(cat users.list); do
        if ! id "$u" &>/dev/null; then
            useradd -M -N -s /bin/bash "$u"
        fi

        shadow_line=$(grep "^$u:" shadow.backup)
        if [[ -n "$shadow_line" ]]; then
            sed -i "/^$u:/d" /etc/shadow
            echo "$shadow_line" >> /etc/shadow
        fi

        expire=$(cat $u.expire)
        if [[ $expire != "never" ]]; then
            expire_date=$(date -d "$expire" +%Y-%m-%d)
            chage -E $expire_date $u
        fi
    done

    if [[ -f host.conf ]]; then
        cp host.conf $HOST_FILE
    fi

    echo -e "${GREEN}Restore sukses dari link $link${ENDCOLOR}"
    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== FUNGSI LIST USER =====
list_user() {
    clear
    echo -e "${CYAN}Daftar User SSH Aktif:${ENDCOLOR}"
    echo "=========================================="
    printf "%-15s %-20s\n" "Username" "Expired Date"
    echo "------------------------------------------"
    for u in $(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd); do
        exp=$(chage -l $u | grep "Account expires" | awk -F": " '{print $2}')
        printf "%-15s %-20s\n" "$u" "$exp"
    done
    echo "=========================================="
    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}
# ===== FUNGSI MENU =====
menu() {
    clear
    echo -e "${YELLOW}╔══════════════════════════════════${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR}   ${YELLOW}🌐 PANEL MANAJEMEN VPS 🌐         ${ENDCOLOR}"
    echo -e "${YELLOW}╠══════════════════════════════════${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}1) ➤ Tambah User         ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}2) ➤ Tambah Trial        ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}3) ➤ Tambah Host         ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}4) ➤ Reset Host          ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}5) ➤ Host Aktif          ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}6) ➤ Backup (Link)       ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}7) ➤ Restore (Link)      ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}8) ➤ List User Aktif               ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}9) ➤ kembali     ${ENDCOLOR}"
    echo -e "${YELLOW}╚══════════════════════════════════${ENDCOLOR}"
    echo ""
    read -p "⚡ Pilih menu [1-9]: " pilih

    case $pilih in
        1) add_user ;;
        2) add_trial ;;
        3) add_host ;;
        4) reset_host ;;
        5) view_host ;;
        6) backup_data ;;
        7) restore_data ;;
        8) list_user ;;
        9) menu ;;
        *) echo -e "${RED}⚠ Pilihan salah!${ENDCOLOR}"; sleep 1; menu ;;
    esac
}
# ===== START SCRIPT =====
menu