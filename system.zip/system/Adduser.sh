#!/bin/bash

# ===== COLORS =====
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
ENDCOLOR="\e[0m"

HOST_FILE="/root/udp/host.conf"

# ===== FUNGSI AMBIL HOST/IP =====
get_host() {
    if [[ -s $HOST_FILE ]]; then
        cat $HOST_FILE
    else
        wget -4 -qO- https://ipecho.net/plain
    fi
}

# ===== FUNGSI TAMBAH USER BIASA =====
add_user() {
    s_ip=$(get_host)

    clear
    echo -ne "${YELLOW}Masukkan username: ${ENDCOLOR}"; read username

    if id "$username" &>/dev/null; then
        echo -e "${RED}User $username sudah ada${ENDCOLOR}"
        sleep 2
        menu
    fi

    echo -ne "Masukkan password: "; read password
    echo -e "${GREEN}Password set successfully!${ENDCOLOR}"

    echo -ne "Masukkan expired (hari): "; read expire_days
    expire_date=$(date -d "$expire_days days" +%Y-%m-%d)
    expire_full=$(date -d "$expire_days days 23:59:59" "+%Y-%m-%d %H:%M:%S")

    read -p "Max logins limit: " maxlogins
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username"

    # Buat user
    useradd -M -N -s /bin/bash $username && echo "$username:$password" | chpasswd

    # Set expired biar SSH tau kadaluarsa
    chage -E $expire_date $username

    # ===== AUTO HAPUS USER SAAT EXPIRED =====
    if ! systemctl is-active --quiet atd; then
        systemctl start atd
        systemctl enable atd
    fi
    echo "userdel -r $username 2>/dev/null" | at "$expire_full"

    clear
    echo -e "${YELLOW}User created successfully!${ENDCOLOR}"
    sleep 1
    clear

    echo -e "\
⚡ SSH & OVPN Account ⚡
========================
🌐 Host/IP    : $s_ip
👤 Username   : $username
🔑 Password   : $password
⏳ Expire     : $expire_full  ( $expire_days hari )
🔒 Max Login  : $maxlogins
========================
🚀 Http Custom UDP
$s_ip:1-65535@$username:$password
========================
📱 Telegram : @JesVpnt
📞 WhatsApp : 6285888801241
========================
"

    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== FUNGSI TAMBAH TRIAL USER RANDOM =====
add_trial() {
    s_ip=$(get_host)

    clear
    # Generate username random: trialXXXX
    username="trial$(openssl rand -hex 3)"
    
    # Pastikan username belum ada
    while id "$username" &>/dev/null; do
        username="trial$(openssl rand -hex 3)"
    done

    # Password random
    password=$(openssl rand -base64 12)
    echo -e "${GREEN}Password set successfully!${ENDCOLOR}"

    # Max login default 1
    maxlogins=1
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username"

    # Buat user
    useradd -M -N -s /bin/bash $username && echo "$username:$password" | chpasswd

    # Set expired (biar SSH tau user kadaluarsa)
    chage -E $(date -d "+1 hour" +%Y-%m-%d) $username

    # ===== AUTO HAPUS TRIAL USER AMAN =====
    # Pastikan service atd aktif
    if ! systemctl is-active --quiet atd; then
        systemctl start atd
        systemctl enable atd
    fi

    # Jadwalkan penghapusan user 1 jam kemudian
    echo "userdel -r $username 2>/dev/null" | at now + 1 hour

    clear
    echo -e "${YELLOW}Trial user created successfully!${ENDCOLOR}"
    sleep 1
    clear

    echo -e "\
⚡ SSH & OVPN Trial Account ⚡
==============================
🌐 Host/IP    : $s_ip
👤 Username   : $username
🔑 Password   : $password
⏳ Expire     : 1 jam
🔒 Max Login  : $maxlogins
==============================
🚀 Http Custom UDP
$s_ip:1-65535@$username:$password
==============================
"

    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== FUNGSI TAMBAH HOST =====
add_host() {
    clear
    echo -ne "${YELLOW}Masukkan IP/Host baru: ${ENDCOLOR}"; read host
    echo "$host" > $HOST_FILE
    echo -e "${GREEN}Host berhasil disimpan: $host${ENDCOLOR}"
    sleep 2
    menu
}

# ===== FUNGSI RESET HOST =====
reset_host() {
    clear
    if [[ -f $HOST_FILE ]]; then
        rm -f $HOST_FILE
        echo -e "${GREEN}Host berhasil direset, kembali ke IP VPS.${ENDCOLOR}"
    else
        echo -e "${YELLOW}Belum ada host custom yang diset.${ENDCOLOR}"
    fi
    sleep 2
    menu
}

# ===== FUNGSI LIHAT HOST AKTIF =====
view_host() {
    clear
    current=$(get_host)
    echo -e "${CYAN}Host/IP yang aktif sekarang:${ENDCOLOR}"
    echo -e "${GREEN}$current${ENDCOLOR}"
    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== FUNGSI MENU =====
menu() {
    clear
    echo -e "${YELLOW}╔══════════════════════════════════${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR}   ${YELLOW}🌐 PANEL MANAJEMEN VPS 🌐         ${ENDCOLOR}"
    echo -e "${YELLOW}╠══════════════════════════════════${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}1) ➤ Tambah User         ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}2) ➤ Tambah Trial        ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}3) ➤ Tambah Host        ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}4) ➤ Reset Host         ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${YELLOW}5) ➤ Host Aktif         ${ENDCOLOR}"
    echo -e "${YELLOW}║${ENDCOLOR} ${RED}6) ➤ Keluar        ${ENDCOLOR}"
    echo -e "${YELLOW}╚══════════════════════════════════${ENDCOLOR}"
    echo ""
    read -p "⚡ Pilih menu [1-6]: " pilih

    case $pilih in
        1) add_user ;;
        2) add_trial ;;
        3) add_host ;;
        4) reset_host ;;
        5) view_host ;;
        6|"") exit 0 ;;
        *) echo -e "${RED}⚠ Pilihan salah!${ENDCOLOR}"; sleep 1; menu ;;
    esac
}

# ===== START SCRIPT =====
menu