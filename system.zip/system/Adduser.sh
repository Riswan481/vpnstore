#!/bin/bash

# ===== WARNA & FORMAT =====
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[93m"
CYAN="\e[36m"
BOLD="\e[1m"
RESET="\e[0m"

# ===== FILE KONFIG & BACKUP =====
HOST_FILE="/root/udp/host.conf"
TG_CONF="/root/udp/telegram.conf"
BACKUP_DIR="/root/udp/backup"
OFFSET_FILE="/root/udp/tg_offset.txt"
EXP_FILE="/root/udp/expired_users.txt"
mkdir -p /root/udp "$BACKUP_DIR"
[[ ! -f $OFFSET_FILE ]] && echo "0" > $OFFSET_FILE
[[ ! -f $EXP_FILE ]] && touch $EXP_FILE

# ===== LOAD TELEGRAM CONFIG =====
[[ -f $TG_CONF ]] && source $TG_CONF

# ===== FUNGSI TELEGRAM =====
send_msg() {
    local msg="$1"
    [[ -z "$BOT_TOKEN" || -z "$CHAT_ID" ]] && return
    curl -s -X POST "https://api.telegram.org/bot${BOT_TOKEN}/sendMessage" \
        -d chat_id="$CHAT_ID" \
        -d parse_mode="HTML" \
        -d text="$msg" >/dev/null
}

# ===== FUNGSI HOST =====
get_host() { [[ -s $HOST_FILE ]] && cat $HOST_FILE || curl -s https://ipecho.net/plain; }
view_host() { 
    local h=$(get_host)
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${GREEN}🌐 Host Aktif : $h${RESET}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    send_msg "🌐 Host Aktif: <code>$h</code>"
}
set_host() { 
    echo "$1" > $HOST_FILE
    echo -e "${GREEN}✅ Host berhasil diubah: $1${RESET}"
    send_msg "✅ Host baru: <code>$1</code>"
}
reset_host() { 
    rm -f $HOST_FILE
    echo -e "${GREEN}✅ Host direset, kembali ke IP VPS${RESET}"
    send_msg "✅ Host direset, kembali ke IP VPS"
}

# ===== FUNGSI USER =====
create_user() {
    local username="$1" password="$2" expire_days="$3" maxlogins="$4" s_ip=$(get_host)
    [[ $(id -u $username 2>/dev/null) ]] && { echo -e "${RED}⚠ User sudah ada${RESET}"; send_msg "⚠ User <b>$username</b> sudah ada!"; return; }

    exp_date=$(date -d "+$expire_days days" +%Y-%m-%d)
    useradd -M -N -s /bin/bash "$username" && echo "$username:$password" | chpasswd
    chage -E "$exp_date" "$username"
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username.conf"
    echo "$username:$exp_date" >> $EXP_FILE

    msg="━━━━━━━━━━━━━━━━━━━━━━
🏪 Riswan Store
✨ Akun UDP Premium
━━━━━━━━━━━━━━━━━━━━━━
🌐 Host/IP : $s_ip
👤 Username : $username
🔑 Password : $password
⏳ Masa Aktif : $expire_days Hari
📅 Expired : $exp_date
🔒 Max Login : $maxlogins
━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "$msg"
    send_msg "$msg"
}

create_trial() {
    local s_ip=$(get_host)
    username="trial$(openssl rand -hex 2)"
    while id "$username" &>/dev/null; do username="trial$(openssl rand -hex 3)"; done
    password=$(openssl rand -base64 3)
    maxlogins=20
    exp_date=$(date -d "+1 day" +%Y-%m-%d)

    useradd -M -N -s /bin/bash "$username" && echo "$username:$password" | chpasswd
    chage -E "$exp_date" "$username"
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username.conf"
    echo "$username:$exp_date" >> $EXP_FILE

    msg="━━━━━━━━━━━━━━━━━━━━━━
🏪 Riswan Store
⚡ TRIAL UDP PREMIUM
━━━━━━━━━━━━━━━━━━━━━━
🌐 Host/IP : $s_ip
👤 Username : $username
🔑 Password : $password
⏳ Masa Aktif : 1 Hari
📅 Expired : $exp_date
🔒 Max Login : $maxlogins
━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "$msg"
    send_msg "$msg"
}

renew_user() {
    read -p "Username: " username
    read -p "Tambah masa aktif (hari): " tambah
    [[ ! $(id -u $username 2>/dev/null) ]] && { echo -e "${RED}❌ User tidak ditemukan${RESET}"; return; }
    exp_lama=$(chage -l $username | grep "Account expires" | awk -F": " '{print $2}')
    [[ "$exp_lama" == "never" ]] && exp_baru=$(date -d "+$tambah days" +%Y-%m-%d) || exp_baru=$(date -d "$exp_lama + $tambah days" +%Y-%m-%d)
    chage -E $exp_baru $username
    sed -i "/^$username:/d" $EXP_FILE
    echo "$username:$exp_baru" >> $EXP_FILE
    echo -e "${GREEN}✅ User $username diperpanjang sampai $exp_baru${RESET}"
    send_msg "✅ User <b>$username</b> diperpanjang sampai $exp_baru"
}

delete_user() {
    read -p "Username yang ingin dihapus: " username
    [[ ! $(id -u $username 2>/dev/null) ]] && { echo -e "${RED}❌ User tidak ditemukan${RESET}"; return; }
    userdel -r $username 2>/dev/null
    rm -f /etc/security/limits.d/$username.conf
    sed -i "/^$username:/d" $EXP_FILE
    echo -e "${GREEN}✅ User $username berhasil dihapus${RESET}"
    send_msg "⚠ User <b>$username</b> dihapus"
}

list_user() {
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${GREEN}📋 Daftar User Aktif${RESET}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    for u in $(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd); do
        exp=$(chage -l "$u" | grep "Account expires" | awk -F": " '{print $2}')
        echo -e "👤 $u : $exp"
    done
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━${RESET}"
}

backup_data() {
    mkdir -p $BACKUP_DIR
    cp $HOST_FILE $BACKUP_DIR/ 2>/dev/null
    cp $TG_CONF $BACKUP_DIR/ 2>/dev/null
    cp $EXP_FILE $BACKUP_DIR/ 2>/dev/null
    tar -czf /root/udp/backup_ssh.tar.gz -C /root/udp backup
    LINK=$(curl -s -F "file=@/root/udp/backup_ssh.tar.gz" https://0x0.st)
    echo -e "${GREEN}✅ Backup selesai: $LINK${RESET}"
    send_msg "✅ Backup berhasil: $LINK"
}

restore_data() {
    read -p "Masukkan link backup: " link
    wget -qO /root/udp/backup_ssh.tar.gz "$link"
    tar -xzf /root/udp/backup_ssh.tar.gz -C /root/udp/
    echo -e "${GREEN}✅ Restore selesai${RESET}"
    send_msg "✅ Restore selesai dari link: $link"
}

delete_expired_users() {
    echo -e "${YELLOW}🔍 Mengecek user expired...${RESET}"
    today=$(date +%s)
    count=0
    [[ ! -f $EXP_FILE ]] && touch $EXP_FILE
    > /tmp/exp_tmp.txt
    while IFS=":" read -r username exp_date; do
        [[ -z "$username" || -z "$exp_date" ]] && continue
        exp_sec=$(date -d "$exp_date" +%s 2>/dev/null)
        [[ -z "$exp_sec" ]] && continue
        if (( today >= exp_sec )); then
            userdel -r "$username" 2>/dev/null
            rm -f /etc/security/limits.d/$username.conf
            echo -e "${RED}⚠ User $username expired ($exp_date) → dihapus${RESET}"
            send_msg "⚠ User <b>$username</b> expired ($exp_date) → dihapus otomatis"
            ((count++))
        else
            echo "$username:$exp_date" >> /tmp/exp_tmp.txt
        fi
    done < $EXP_FILE
    mv /tmp/exp_tmp.txt $EXP_FILE 2>/dev/null
    echo -e "${GREEN}✅ Total $count user expired dihapus${RESET}"
}

# ===== TELEGRAM POLLING BACKGROUND =====
telegram_polling() {
    [[ -z "$BOT_TOKEN" || -z "$CHAT_ID" ]] && return
    BOT_API="https://api.telegram.org/bot$BOT_TOKEN"
    while true; do
        OFFSET=$(cat $OFFSET_FILE)
        RESPONSE=$(curl -s "$BOT_API/getUpdates?timeout=30&offset=$OFFSET")
        for row in $(echo "$RESPONSE" | jq -c '.result[]'); do
            UPDATE_ID=$(echo $row | jq '.update_id')
            CHAT_ID_MSG=$(echo $row | jq '.message.chat.id')
            TEXT=$(echo $row | jq -r '.message.text')
            OFFSET=$((UPDATE_ID + 1))
            echo $OFFSET > $OFFSET_FILE
            [["$CHAT_ID_MSG" != "$CHAT_ID" ]] && continue
            case $TEXT in
                "/add trial") create_trial ;;
                "/list") list_user ;;
                /delete*) u=$(echo $TEXT | awk '{print $2}'); delete_user "$u" ;;
            esac
        done
        sleep 1
    done
}

start_telegram_polling_bg() {
    [[ -z "$BOT_TOKEN" || -z "$CHAT_ID" ]] && return
    if ! pgrep -f "ssh_manager.sh" >/dev/null 2>&1; then
        nohup bash "$0" telegram_polling >/root/udp/telegram_polling.log 2>&1 &
        echo -e "${GREEN}✅ Telegram polling berjalan di background${RESET}"
    fi
}

# ===== MENU UTAMA =====
menu() {
    clear
    echo -e "${YELLOW}╔══════════════════════════════════${RESET}"
    echo -e "${YELLOW}║   🌐 PANEL MANAJEMEN VPS 🌐       ${RESET}"
    echo -e "${YELLOW}╠══════════════════════════════════${RESET}"
    echo -e "${YELLOW}║ 1) Tambah User${RESET}"
    echo -e "${YELLOW}║ 2) Tambah Trial${RESET}"
    echo -e "${YELLOW}║ 3) Perpanjang User${RESET}"
    echo -e "${YELLOW}║ 4) Hapus User${RESET}"
    echo -e "${YELLOW}║ 5) List User Aktif${RESET}"
    echo -e "${YELLOW}║ 6) Host Aktif${RESET}"
    echo -e "${YELLOW}║ 7) Set Host${RESET}"
    echo -e "${YELLOW}║ 8) Reset Host${RESET}"
    echo -e "${YELLOW}║ 9) Backup link${RESET}"
    echo -e "${YELLOW}║ 10) Restore link${RESET}"
    echo -e "${YELLOW}║ 11) Set Notif Bot${RESET}"
    echo -e "${YELLOW}║ 12) Hapus User Expired${RESET}"
    echo -e "${YELLOW}║ 0) Keluar${RESET}"
    echo -e "${YELLOW}╚══════════════════════════════════${RESET}"
    echo ""
    read -p "⚡ Pilih menu [0-12]: " pilih
    case $pilih in
        1) read -p "Username: " u; read -p "Password: " p; read -p "Expired (hari): " e; read -p "Max login: " m; create_user "$u" "$p" "$e" "$m" ;;
        2) create_trial ;;
        3) renew_user ;;
        4) delete_user ;;
        5) list_user ;;
        6) view_host ;;
        7) read -p "Masukkan host/IP: " h; set_host "$h" ;;
        8) reset_host ;;
        9) backup_data ;;
        10) restore_data ;;
        11) read -p "Masukkan BOT TOKEN Telegram: " bot_token; read -p "Masukkan CHAT ID Telegram: " chat_id; echo "BOT_TOKEN=\"$bot_token\"" > $TG_CONF; echo "CHAT_ID=\"$chat_id\"" >> $TG_CONF; source $TG_CONF; echo -e "${GREEN}✅ BOT TOKEN & CHAT ID berhasil disimpan${RESET}" ;;
        12) delete_expired_users ;;
        0|"") exit 0 ;;
        *) echo -e "${RED}⚠ Pilihan salah!${RESET}"; sleep 1 ;;
    esac
    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== PASANG CRON & SCRIPT EKSEKUSI =====
SCRIPT_PATH="$(realpath "$0")"
chmod +x "$SCRIPT_PATH"

# Auto hapus expired tiap jam
(crontab -l 2>/dev/null; echo "0 * * * * $SCRIPT_PATH hapus_expired >> /var/log/hapus_expired.log 2>&1") | crontab -

# ===== START SCRIPT =====
case "$1" in
    expired|hapus_expired)
        delete_expired_users
        exit 0
        ;;
    telegram_polling)
        telegram_polling
        ;;
    *)
        start_telegram_polling_bg
        menu
        ;;
esac