#!/bin/bash

# ===== COLORS =====
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
ENDCOLOR="\e[0m"

# ===== FILE KONFIG & BACKUP =====
HOST_FILE="/root/udp/host.conf"
TG_CONF="/root/udp/telegram.conf"
BACKUP_DIR="/root/udp/backup"
OFFSET_FILE="/root/udp/tg_offset.txt"
mkdir -p /root/udp $BACKUP_DIR
[[ ! -f $OFFSET_FILE ]] && echo "0" > $OFFSET_FILE

# ===== LOAD TELEGRAM CONFIG =====
if [[ -f $TG_CONF ]]; then
    source $TG_CONF
fi

# ===== FUNGSI KIRIM PESAN TELEGRAM =====
send_msg() {
    local msg="$1"
    [[ -z "$BOT_TOKEN" || -z "$CHAT_ID" ]] && return
    curl -s -X POST "https://api.telegram.org/bot${BOT_TOKEN}/sendMessage" \
        -d chat_id="$CHAT_ID" \
        -d parse_mode="HTML" \
        -d text="$msg" >/dev/null
}

# ===== FUNGSI HOST =====
get_host() { 
    [[ -s $HOST_FILE ]] && cat $HOST_FILE || curl -s https://ipecho.net/plain
}

view_host() { 
    local current_host=$(get_host)

    # Telegram
    msg="🏪 <b>Riswan Store</b>
🌐 <b>Host/IP Aktif:</b> <code>$current_host</code>"
    
    # Terminal
    msg_terminal="🏪 Riswan Store
🌐 Host/IP Aktif: $current_host"

    echo -e "$msg_terminal"
    send_msg "$msg"
}

set_host() { 
    echo "$1" > $HOST_FILE

    # Telegram
    msg="🏪 <b>Riswan Store</b>
✅ <b>Host berhasil diubah!</b>
━━━━━━━━━━━━━━━━━━━━━━
🌐 Host Baru : <code>$1</code>
━━━━━━━━━━━━━━━━━━━━━━"

    # Terminal
    msg_terminal="🏪 Riswan Store
✅ Host berhasil diubah!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌐 Host Baru : $1
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    echo -e "$msg_terminal"
    send_msg "$msg"
}

reset_host() { 
    rm -f $HOST_FILE

    # Telegram
    msg="🏪 <b>Riswan Store</b>
✅ <b>Host berhasil direset!</b>
━━━━━━━━━━━━━━━━━━━━━━
🌐 Sekarang kembali ke IP VPS
━━━━━━━━━━━━━━━━━━━━━━"

    # Terminal
    msg_terminal="🏪 Riswan Store
✅ Host berhasil direset!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌐 Sekarang kembali ke IP VPS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    echo -e "$msg_terminal"
    send_msg "$msg"
}

# ===== FUNGSI USER =====
create_user() {
    local username="$1" password="$2" expire_days="$3" maxlogins="$4" s_ip=$(get_host)

    if id "$username" &>/dev/null; then
        send_msg "⚠ User <b>$username</b> sudah ada!"
        echo "⚠ User $username sudah ada!"
        return
    fi

    # Hitung tanggal expired
    exp_date=$(date -d "+$expire_days days" +"%d %b %Y")

    useradd -M -N -s /bin/bash "$username" && echo "$username:$password" | chpasswd
    chage -E "$(date -d "+$expire_days days" +%Y-%m-%d)" "$username"
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username.conf"

    # Pesan Telegram
    msg="
━━━━━━━━━━━━━━━━━━━━━━
🏪 <b>Riswan Store</b>
✨ <b>Akun UDP Premium</b> ✨
━━━━━━━━━━━━━━━━━━━━━━
🌐 Host/IP : <code>$s_ip</code>
👤 Username : <code>$username</code>
🔑 Password : <code>$password</code>
⏳ Masa Aktif : <code>$expire_days Hari</code>
📅 Expired : <code>$exp_date</code>
🔒 Max Login : <code>$maxlogins</code>
🎯 udp : <code>$s_ip:1-65535@$username:$password</code>
━━━━━━━━━━━━━━━━━━━━━━
🔥 Nikmati koneksi cepat stabil
💎 Hanya di <b>Riswan Store</b>!
━━━━━━━━━━━━━━━━━━━━━━"

    # Pesan Terminal
    msg_terminal="
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏪 Riswan Store
✨ Akun UDP Premium ✨
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌐 Host/IP : $s_ip
👤 Username : $username
🔑 Password : $password
⏳ Masa Aktif : $expire_days Hari
📅 Expired : $exp_date
🔒 Max Login : $maxlogins
🎯 udp : $s_ip:1-65535@$username:$password
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔥 Nikmati koneksi cepat stabil
💎 Hanya di Riswan Store!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    send_msg "$msg"
    echo -e "$msg_terminal"
}

create_trial() {
    local s_ip=$(get_host)
    username="trial$(openssl rand -hex 2)"
    while id "$username" &>/dev/null; do 
        username="trial$(openssl rand -hex 3)"
    done
    password=$(openssl rand -base64 3)
    maxlogins=20

    # Hitung expired trial (1 hari)
    exp_date=$(date -d "+1 day" +"%d %b %Y")

    useradd -M -N -s /bin/bash $username && echo "$username:$password" | chpasswd
    chage -E "$(date -d "+1 day" +%Y-%m-%d)" $username
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username.conf"

    # Pesan Telegram
    msg="━━━━━━━━━━━━━━━━━━━━━━
🏪 <b>Riswan Store</b>
⚡ <b>TRIAL UDP PREMIUM</b> ⚡
━━━━━━━━━━━━━━━━━━━━━━
🌐 Host/IP : <code>$s_ip</code>
👤 Username : <code>$username</code>
🔑 Password : <code>$password</code>
⏳ Masa Aktif : <code>1 Hari</code>
📅 Expired : <code>$exp_date</code>
🔒 Max Login : <code>$maxlogins</code>
🎯 udp : <code>$s_ip:1-65535@$username:$password</code>
━━━━━━━━━━━━━━━━━━━━━━
🔥 Coba koneksi cepat stabil
💎 Hanya di <b>Riswan Store</b>!
━━━━━━━━━━━━━━━━━━━━━━
👤 Admin tele <code>t.me/JesVpnt</code>
🌐 Grup tele <code>t.me/grupvpn</code>
👤 Admin wa <code>wa.me/6285888801241</code>
📄 Ikuti saluran kami di wa
👉 <code>https://whatsapp.com/channel/0029VamUr1QJuyAFhT7ife3K</code>
━━━━━━━━━━━━━━━━━━━━━━"

    # Pesan Terminal
    msg_terminal="
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏪 Riswan Store
⚡ TRIAL UDP PREMIUM ⚡
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌐 Host/IP : $s_ip
👤 Username : $username
🔑 Password : $password
⏳ Masa Aktif : 1 Hari
📅 Expired : $exp_date
🔒 Max Login : $maxlogins
🎯 udp : $s_ip:1-65535@$username:$password
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔥 Coba koneksi cepat & stabil
💎 Hanya di Riswan Store!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    send_msg "$msg"
    echo -e "$msg_terminal"
}

renew_user() {
    clear
    echo -ne "${YELLOW}Masukkan username: ${ENDCOLOR}"; read username
    echo -ne "Tambah masa aktif (hari): "; read tambah

    if ! id "$username" &>/dev/null; then
        echo -e "${RED}User $username tidak ditemukan!${ENDCOLOR}"
        return
    fi

    exp_lama=$(chage -l $username | grep "Account expires" | awk -F": " '{print $2}')
    [[ "$exp_lama" == "never" ]] \
        && exp_baru=$(date -d "+$tambah days" +%Y-%m-%d) \
        || exp_baru=$(date -d "$exp_lama + $tambah days" +%Y-%m-%d)

    chage -E $exp_baru $username

    # Pesan untuk Telegram
    msg="
━━━━━━━━━━━━━━━━━━━━━━
🏪 <b>Riswan Store</b>
✅ <b>Akun Berhasil Diperpanjang!</b>
━━━━━━━━━━━━━━━━━━━━━━
👤 Username : <code>$username</code>
📅 Expired Lama : <code>$exp_lama</code>
📅 Expired Baru : <code>$exp_baru</code>
➕ Perpanjangan : <code>$tambah Hari</code>
━━━━━━━━━━━━━━━━━━━━━━
🔥 Tetap nikmati koneksi stabil
💎 Hanya di <b>Riswan Store</b>!
━━━━━━━━━━━━━━━━━━━━━━
👤 Admin tele <code>t.me/JesVpnt</code>
🌐 Grup tele <code>t.me/grupvpn</code>
👤 Admin wa <code>wa.me/6285888801241</code>
📄 Ikuti saluran kami di wa
👉 <code>https://whatsapp.com/channel/0029VamUr1QJuyAFhT7ife3K</code>
━━━━━━━━━━━━━━━━━━━━━━"

# Pesan untuk Terminal
msg_terminal="
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏪 Riswan Store
✅ Akun Berhasil Diperpanjang!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
👤 Username : $username
📅 Expired Lama : $exp_lama
📅 Expired Baru : $exp_baru
➕ Perpanjangan : $tambah Hari
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔥 Tetap nikmati koneksi stabil
💎 Hanya di Riswan Store!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    # Kirim ke Telegram
    send_msg "$msg"
    # Tampilkan di Terminal
    echo -e "$msg_terminal"
}

delete_user() {
    clear
    echo -ne "${YELLOW}Masukkan username yang ingin dihapus: ${ENDCOLOR}"; read username

    if ! id "$username" &>/dev/null; then
        echo -e "${RED}User $username tidak ditemukan!${ENDCOLOR}"
        return
    fi

    userdel -r $username 2>/dev/null
    rm -f /etc/security/limits.d/$username.conf

    # Pesan untuk Telegram
    msg="
━━━━━━━━━━━━━━━━━━━━━━
🏪 <b>Riswan Store</b>
✅ <b>User Berhasil Dihapus!</b>
━━━━━━━━━━━━━━━━━━━━━━
👤 Username : <code>$username</code>
━━━━━━━━━━━━━━━━━━━━━━
🔥 Akun berhasil dihapus dari server
💎 Hanya di <b>Riswan Store</b>!
━━━━━━━━━━━━━━━━━━━━━━"

# Pesan untuk Terminal
msg_terminal="
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏪 Riswan Store
✅ User Berhasil Dihapus!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
👤 Username : $username
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔥 Akun berhasil dihapus dari server
💎 Hanya di Riswan Store!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    # Kirim ke Telegram
    send_msg "$msg"
    # Tampilkan di Terminal
    echo -e "$msg_terminal"
}

list_user() {
    # Header untuk Telegram
    msg="🏪 <b>Riswan Store</b>
📋 <b>Daftar User Aktif</b>
━━━━━━━━━━━━━━━━━━━━━━
"

    # Header untuk Terminal  
    msg_terminal="🏪 Riswan Store

📋 Daftar User Aktif
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"

    count=0
    # Loop semua user dengan UID >= 1000 (user normal)  
    for u in $(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd); do  
        exp=$(chage -l "$u" | grep "Account expires" | awk -F": " '{print $2}')  
        msg+="👤 <code>$u : $exp</code>
"  
        msg_terminal+="👤 $u : $exp\n"  
        ((count++))
    done  

    msg+="━━━━━━━━━━━━━━━━━━━━━━
📊 Total User Aktif: <b>$count</b>
━━━━━━━━━━━━━━━━━━━━━━"
    msg_terminal+="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 Total User Aktif: $count
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    # Kirim ke Telegram  
    send_msg "$msg"  
    # Tampilkan di Terminal  
    echo -e "$msg_terminal"
}

# ===== TELEGRAM CONFIG =====
set_telegram() {
    clear
    echo -ne "${YELLOW}Masukkan BOT TOKEN Telegram: ${ENDCOLOR}"; read bot_token
    echo -ne "${YELLOW}Masukkan CHAT ID Telegram: ${ENDCOLOR}"; read chat_id
    echo "BOT_TOKEN=\"$bot_token\"" > $TG_CONF
    echo "CHAT_ID=\"$chat_id\"" >> $TG_CONF
    source $TG_CONF
    echo -e "${GREEN}BOT TOKEN & CHAT ID berhasil disimpan!${ENDCOLOR}"
    sleep 2
}

# ===== BACKUP & RESTORE =====
backup_data() { 
    mkdir -p $BACKUP_DIR
    awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd > $BACKUP_DIR/users.list
    > $BACKUP_DIR/shadow.backup
    for u in $(cat $BACKUP_DIR/users.list); do
        chage -l $u | grep "Account expires" | awk -F": " '{print $2}' > $BACKUP_DIR/$u.expire
        grep "^$u:" /etc/shadow >> $BACKUP_DIR/shadow.backup
    done
    [[ -f $HOST_FILE ]] && cp $HOST_FILE $BACKUP_DIR/
    tar -czf /root/udp/backup_ssh.tar.gz -C /root/udp backup
    LINK=$(curl -s -F "file=@/root/udp/backup_ssh.tar.gz" https://0x0.st)

    # Pesan Telegram
    msg="
━━━━━━━━━━━━━━━━━━━━━━
🏪 <b>Riswan Store</b>
✅ <b>Backup Berhasil!</b>
━━━━━━━━━━━━━━━━━━━━━━
🔗 Link Backup : 
🎯 <code>$LINK</code>
━━━━━━━━━━━━━━━━━━━━━━
🔥 Backup aman tersimpan
💎 Hanya di <b>Riswan Store</b>!
━━━━━━━━━━━━━━━━━━━━━━"

# Pesan Terminal
msg_terminal="
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏪 Riswan Store
✅ Backup Berhasil!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔗 Link Backup : 
🎯 $LINK
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔥 Backup aman tersimpan
💎 Hanya di Riswan Store!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    echo -e "$msg_terminal"
    send_msg "$msg"
}

restore_data() { 
    echo -ne "${YELLOW}Masukkan link backup: ${ENDCOLOR}"; read link
    wget -qO /root/udp/backup_ssh.tar.gz "$link"
    tar -xzf /root/udp/backup_ssh.tar.gz -C /root/udp/
    cd /root/udp/backup

    for u in $(cat users.list); do
        [[ ! $(id -u $u 2>/dev/null) ]] && useradd -M -N -s /bin/bash $u
        shadow_line=$(grep "^$u:" shadow.backup)
        [[ -n "$shadow_line" ]] && (sed -i "/^$u:/d" /etc/shadow && echo "$shadow_line" >> /etc/shadow)
        expire=$(cat $u.expire)
        [[ $expire != "never" ]] && chage -E $(date -d "$expire" +%Y-%m-%d) $u
    done

    [[ -f host.conf ]] && cp host.conf $HOST_FILE

    # Pesan Telegram
    msg="
━━━━━━━━━━━━━━━━━━━━━━
🏪 <b>Riswan Store</b>
✅ <b>Restore Berhasil!</b>
━━━━━━━━━━━━━━━━━━━━━━
🔗 Sumber Link : 
🎯 <code>$link</code>
━━━━━━━━━━━━━━━━━━━━━━
🔥 Data berhasil dipulihkan
💎 Hanya di <b>Riswan Store</b>!
━━━━━━━━━━━━━━━━━━━━━━"

# Pesan Terminal
msg_terminal="
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏪 Riswan Store
✅ Restore Berhasil!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔗 Sumber Link : 
🎯 $link
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔥 Data berhasil dipulihkan
💎 Hanya di Riswan Store!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    echo -e "$msg_terminal"
    send_msg "$msg"
}

# ===== AUTO HAPUS USER EXPIRED =====
auto_expired() {
    LOG_FILE="/var/log/expired_users.log"
    mkdir -p /var/log
    > $LOG_FILE
    for user in $(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd); do
        exp_date=$(chage -l $user | grep "Account expires" | awk -F": " '{print $2}')
        if [[ "$exp_date" != "never" && "$exp_date" != "Account expires" ]]; then
            exp_sec=$(date -d "$exp_date" +%s)
            now_sec=$(date +%s)
            if [[ $exp_sec -lt $now_sec ]]; then
                echo "$(date) : $user expired ($exp_date) → dihapus" >> $LOG_FILE
                userdel -r $user 2>/dev/null
                rm -f /etc/security/limits.d/$user.conf
                send_msg "⚠ User <b>$user</b> expired ($exp_date) → dihapus otomatis."
            fi
        fi
    done
}

# ===== AUTO SET CRON UNTUK HAPUS EXPIRED =====
setup_cron() {
    CRON_CMD="/bin/bash /root/udp/ssh_manager.sh expired >/dev/null 2>&1"
    CRON_JOB="0 0 * * * $CRON_CMD"
    if ! crontab -l 2>/dev/null | grep -q "$CRON_CMD"; then
        (crontab -l 2>/dev/null; echo "$CRON_JOB") | crontab -
        echo -e "${GREEN}Cronjob auto expired berhasil dipasang (jalan tiap jam 00:00)${ENDCOLOR}"
    fi
}

# ===== TELEGRAM POLLING =====
telegram_polling() {
    [[ -z "$BOT_TOKEN" || -z "$CHAT_ID" ]] && return
    BOT_API="https://api.telegram.org/bot$BOT_TOKEN"
    while true; do
        OFFSET=$(cat $OFFSET_FILE)
        RESPONSE=$(curl -s "$BOT_API/getUpdates?timeout=30&offset=$OFFSET")
        for row in $(echo "$RESPONSE" | jq -c '.result[]'); do
            UPDATE_ID=$(echo $row | jq '.update_id')
            CHAT_ID_MSG=$(echo $row | jq '.message.chat.id')
            TEXT=$(echo $row | jq -r '.message.text')
            OFFSET=$((UPDATE_ID + 1))
            echo $OFFSET > $OFFSET_FILE
            [[ "$CHAT_ID_MSG" != "$CHAT_ID" ]] && continue
            case $TEXT in
                "/add trial") create_trial ;;
                "/list") list_user ;;
                /delete*) u=$(echo $TEXT | awk '{print $2}'); delete_user "$u" ;;
            esac
        done
        sleep 1
    done
}

# ===== AUTO JALANKAN TELEGRAM POLLING DI BACKGROUND =====
start_telegram_polling_bg() {
    [[ -z "$BOT_TOKEN" || -z "$CHAT_ID" ]] && return
    if ! pgrep -f "ssh_manager.sh" >/dev/null 2>&1; then
        nohup bash "$0" >/root/udp/telegram_polling.log 2>&1 &
        echo -e "${GREEN}✅ Telegram polling berjalan di background${ENDCOLOR}"
    fi
}
# ===== HAPUS SEMUA USER EXPIRED SECARA MANUAL =====
delete_expired_users() {
    echo -e "${YELLOW}🔍 Mengecek user expired...${ENDCOLOR}"
    count=0
    for user in $(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd); do
        exp_date=$(chage -l $user | grep "Account expires" | awk -F": " '{print $2}')
        if [[ "$exp_date" != "never" && "$exp_date" != "Account expires" ]]; then
            exp_sec=$(date -d "$exp_date" +%s)
            now_sec=$(date +%s)
            if [[ $exp_sec -lt $now_sec ]]; then
                userdel -r $user 2>/dev/null
                rm -f /etc/security/limits.d/$user.conf
                echo -e "${RED}⚠ User $user expired ($exp_date) → dihapus${ENDCOLOR}"
                send_msg "⚠ User <b>$user</b> expired ($exp_date) → dihapus manual."
                ((count++))
            fi
        fi
    done
    if [[ $count -eq 0 ]]; then
        echo -e "${GREEN}✅ Tidak ada user expired.${ENDCOLOR}"
    else
        echo -e "${GREEN}✅ Total $count user expired berhasil dihapus.${ENDCOLOR}"
    fi
}
# ===== MENU =====
menu() {
    clear
    echo -e "${YELLOW}╔══════════════════════════════════${ENDCOLOR}"
    echo -e "${YELLOW}║   🌐 PANEL MANAJEMEN VPS 🌐       ${ENDCOLOR}"
    echo -e "${YELLOW}╠══════════════════════════════════${ENDCOLOR}"
    echo -e "${YELLOW}║ 1) Tambah User"
    echo -e "${YELLOW}║ 2) Tambah Trial"
    echo -e "${YELLOW}║ 3) Perpanjang User"
    echo -e "${YELLOW}║ 4) Hapus User"
    echo -e "${YELLOW}║ 5) List User Aktif"
    echo -e "${YELLOW}║ 6) Host Aktif"
    echo -e "${YELLOW}║ 7) Set Host"
    echo -e "${YELLOW}║ 8) Reset Host"
    echo -e "${YELLOW}║ 9) Backup link"
    echo -e "${YELLOW}║10) Restore link "
    echo -e "${YELLOW}║11) Set Notif Bot"
    echo -e "${YELLOW}║12) Hapus User Expired"
    echo -e "${YELLOW}║ 0) Keluar"
    echo -e "${YELLOW}╚══════════════════════════════════${ENDCOLOR}"
    echo ""
    read -p "⚡ Pilih menu [0-11]: " pilih
    case $pilih in
        1) echo -ne "Username: "; read u; echo -ne "Password: "; read p; echo -ne "Expired (hari): "; read e; echo -ne "Max login: "; read m; create_user "$u" "$p" "$e" "$m" ;;
        2) create_trial ;;
        3) renew_user ;;
        4) delete_user ;;
        5) list_user ;;
        6) view_host ;;
        7) echo -ne "Masukkan host/IP: "; read h; set_host "$h" ;;
        8) reset_host ;;
        9) backup_data ;;
        10) restore_data ;;
        11) set_telegram ;;
        12) delete_expired_users ;;
        0|"") exit 0 ;;
        *) echo -e "${RED}⚠ Pilihan salah!${ENDCOLOR}"; sleep 1; menu ;;
    esac
    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== START SCRIPT =====
if [[ "$1" == "expired" ]]; then
    auto_expired
    exit 0
else
    setup_cron
    start_telegram_polling_bg
    menu
fi