#!/bin/bash

# ===== WARNA =====
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[93m"
CYAN="\e[36m"
CYAN_BRIGHT="\e[96m"
BOLD="\e[1m"
RESET="\e[0m"

# ===== PASTIKAN DIJALANKAN ROOT =====
if [ "$(id -u)" -ne 0 ]; then
    echo -e "${RED}Please run the command with root privileges!${RESET}"
    exit 1
fi

# ===== CEK IP TERDAFTAR =====
MYIP=$(curl -4 -s icanhazip.com)
line=$(curl -s https://raw.githubusercontent.com/Riswan481/vpnstore/main/REGIST | grep "$MYIP")

if [ -z "$line" ]; then
    echo -e "${RED}IP $MYIP tidak terdaftar di REGIST!${RESET}"
    echo -e "${YELLOW}Mohon hubungi admin untuk registrasi.${RESET}"
    exit 1
fi

# Ambil username, expired, dan IP
username=$(echo "$line" | awk '{print $2}')
expired=$(echo "$line" | awk '{print $3}')
ip=$(echo "$line" | awk '{print $4}')

# ===== HITUNG SISA HARI =====
today=$(date +%Y-%m-%d)
expiry_sec=$(date -d "$expired" +%s)
today_sec=$(date -d "$today" +%s)
diff_days=$(( (expiry_sec - today_sec) / 86400 ))

if [[ $diff_days -lt 0 ]]; then
    echo -e "${RED}User $username sudah expired pada $expired!${RESET}"
    echo -e "${YELLOW}Mohon perpanjang akses terlebih dahulu.${RESET}"
    exit 1
fi

# ===== EKSEKUSI OTOMATIS SCRIPT SYSTEM =====
SYSTEM_DIR="/etc/Sslablk/system"
if [ -d "$SYSTEM_DIR" ]; then
    chmod +x "$SYSTEM_DIR"/*.sh
    echo -e "${GREEN}All scripts in $SYSTEM_DIR are now executable.${RESET}"
else
    echo -e "${RED}System directory $SYSTEM_DIR not found!${RESET}"
    exit 1
fi

# ===== FUNSI TOTAL USER =====
total_user() {
    awk -F: '$3 >= 1000 {print $1}' /etc/passwd | grep -v nobody | wc -l
}

# ===== FUNSI AMBIL HOST =====
get_host() {
    HOST_FILE="/root/udp/host.conf"
    if [ -f "$HOST_FILE" ]; then
        cat "$HOST_FILE"
    else
        echo "Host file not found"
    fi
}

# ===== MENU UTAMA =====
menu_main() {
    clear
    os_info=$(grep PRETTY_NAME /etc/os-release | cut -d '=' -f2 | tr -d '"')
    pub_ip=$(curl -4 -s icanhazip.com)
    region=$(curl -s https://ipinfo.io/"$pub_ip"/region)
    [[ -z "$region" ]] && region="Unknown"
    user_total=$(total_user)
    current_host=$(get_host)
    current_time=$(date +"%H:%M:%S")

    # ===== HEADER GRADIENT =====
    GRAD1="\e[38;5;39m"
    GRAD2="\e[38;5;45m"
    GRAD3="\e[38;5;51m"
    MENU_NUM="\e[38;5;226m"
    MENU_TEXT="\e[38;5;15m"
    INFO_LABEL="\e[38;5;220m"
    INFO_VALUE="\e[38;5;15m"

    echo -e "${GRAD2}${BOLD}┌─────────────────────────────────────────────┐${RESET}"
    echo -e "${GRAD2}${BOLD}│ ${INFO_LABEL}🖥️ OS        :${RESET} ${INFO_VALUE}$os_info${RESET}"
    echo -e "${GRAD2}${BOLD}│ ${INFO_LABEL}🌐 Public IP :${RESET} ${INFO_VALUE}$pub_ip${RESET}"
    echo -e "${GRAD2}${BOLD}│ ${INFO_LABEL}📍 Region    :${RESET} ${INFO_VALUE}$region${RESET}"
    echo -e "${GRAD2}${BOLD}│ ${INFO_LABEL}👤 Username  :${RESET} ${INFO_VALUE}$username${RESET}"
    echo -e "${GRAD2}${BOLD}│ ${INFO_LABEL}🗓️ Expired   :${RESET} ${INFO_VALUE}$expired${RESET}"
    echo -e "${GRAD2}${BOLD}│ ${INFO_LABEL}⏳ Sisa Hari :${RESET} ${INFO_VALUE}$diff_days Hari${RESET}"
    echo -e "${GRAD2}${BOLD}│ ${INFO_LABEL}👥 Total User:${RESET} ${INFO_VALUE}$user_total User${RESET}"
    echo -e "${GRAD2}${BOLD}│ ${INFO_LABEL}🌐 Host      :${RESET} ${INFO_VALUE}$current_host${RESET}"
    echo -e "${GRAD2}${BOLD}│ ${INFO_LABEL}🕒 Jam       :${RESET} ${INFO_VALUE}$current_time${RESET}"
    echo -e "${GRAD2}${BOLD}└─────────────────────────────────────────────┘${RESET}"

    # ===== MENU OPTIONS =====
    echo -e "${GRAD3}${BOLD}┌─────────────────────────────────────────────┐${RESET}"
    echo -e "${GRAD3}${BOLD}│ ${MENU_NUM}1) ${MENU_TEXT}➕ Add New Users${RESET}"
    echo -e "${GRAD3}${BOLD}│ ${MENU_NUM}2) ${MENU_TEXT}❌ Delete User${RESET}"
    echo -e "${GRAD3}${BOLD}│ ${MENU_NUM}3) ${MENU_TEXT}🚫 Torrent Blocker${RESET}"
    echo -e "${GRAD3}${BOLD}│ ${MENU_NUM}4) ${MENU_TEXT}🔄 Restart UDP Service${RESET}"
    echo -e "${GRAD3}${BOLD}│ ${MENU_NUM}5) ${MENU_TEXT}⬆️ Update Scripts/System${RESET}"
    echo -e "${GRAD3}${BOLD}│ ${MENU_NUM}6) ${MENU_TEXT}💾 Backup / Restore VPS${RESET}"
    echo -e "${GRAD3}${BOLD}└─────────────────────────────────────────────┘${RESET}"

    read -rp "${MENU_NUM}Select Operation [1-6]: ${RESET}" choice

    case $choice in
        1) "$SYSTEM_DIR"/Adduser.sh ;;
        2) "$SYSTEM_DIR"/DelUser.sh ;;
        3) "$SYSTEM_DIR"/torrent.sh ;;
        4)
            if systemctl restart udp-custom; then
                echo -e "${GREEN}UDP Custom restarted successfully.${RESET}"
            else
                echo -e "${RED}Failed to restart UDP Custom.${RESET}"
            fi
            sleep 2
            menu_main
            ;;
        5)
            echo -e "${YELLOW}Installing / Reinstalling scripts...${RESET}"
            wget -q "https://raw.githubusercontent.com/Riswan481/vpnstore/main/install.sh" -O /tmp/install.sh
            if [ -f /tmp/install.sh ]; then
                chmod +x /tmp/install.sh
                bash /tmp/install.sh
            else
                echo -e "${RED}Failed to download install script!${RESET}"
            fi
            sleep 2
            menu_main
            ;;
        6) menu_backup ;;
        *) echo -e "${RED}Invalid Option!${RESET}"; sleep 2; menu_main ;;
    esac
}

# ===== MENU BACKUP VPS =====
menu_backup() {
    clear
    BLUE_CYAN="\e[5;36m"
    echo -e "${BLUE_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "         ${BOLD}MENU BACKUP VPS${RESET}"
    echo -e "${BLUE_CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${YELLOW}1) Backup VPS${RESET}"
    echo -e "${YELLOW}2) Restore VPS${RESET}"
    echo -e "${YELLOW}3) Start Service${RESET}"
    echo -e "${YELLOW}4) Limit Speed${RESET}"
    echo -e "${YELLOW}5) Auto Backup${RESET}"

    read -rp "Pilih Nomor └╼>>> " bro

    case $bro in
        1) ./men-backup.sh backup ;;
        2) ./men-backup.sh restore ;;
        3) ./men-backup.sh strt ;;
        4) ./men-backup.sh limitspeed ;;
        5) ./men-backup.sh autobackup ;;
        *) echo -e "${RED}Invalid Option!${RESET}"; sleep 2 ;;
    esac

    echo -e "${GREEN}Terimakasih sudah menggunakan layanan Autoscript Jesstunnel${RESET}"
    read -rp "Press Enter to return to main menu..." dummy
    menu_main
}

# ===== PANGGIL MENU UTAMA =====
menu_main