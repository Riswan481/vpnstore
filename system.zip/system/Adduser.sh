#!/bin/bash

# ===== COLORS =====
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
ENDCOLOR="\e[0m"

# ===== FILE KONFIG & BACKUP =====
HOST_FILE="/root/udp/host.conf"
TG_CONF="/root/udp/telegram.conf"
BACKUP_DIR="/root/udp/backup"
OFFSET_FILE="/root/udp/tg_offset.txt"
mkdir -p /root/udp $BACKUP_DIR
[[ ! -f $OFFSET_FILE ]] && echo "0" > $OFFSET_FILE

# ===== LOAD TELEGRAM CONFIG =====
[[ -f $TG_CONF ]] && source $TG_CONF

# ===== UTILITY =====
escape_md() { echo "$1" | sed -E 's/([_*\[\]()~`>#+\-=|{}.!])/\\\1/g'; }
format_msg() { echo -e "===========================\n$1\n===========================\n$2\n==========================="; }

# ===== HOST MANAGEMENT =====
get_host() { [[ -s $HOST_FILE ]] && cat $HOST_FILE || curl -s https://ipecho.net/plain; }
view_host() { msg="🌐 Host/IP Aktif: $(get_host)"; echo -e "$msg"; [[ ! -z $CHAT_ID ]] && send_msg "$CHAT_ID" "$(escape_md "$msg")"; }
set_host() { echo "$1" > $HOST_FILE; msg="✅ Host berhasil diubah: $1"; echo -e "$msg"; [[ ! -z $CHAT_ID ]] && send_msg "$CHAT_ID" "$(escape_md "$msg")"; }
reset_host() { rm -f $HOST_FILE; msg="✅ Host direset ke IP VPS"; echo -e "$msg"; [[ ! -z $CHAT_ID ]] && send_msg "$CHAT_ID" "$(escape_md "$msg")"; }

# ===== USER MANAGEMENT =====
create_user() {
    local username="$1" password="$2" expire_days="$3" maxlogins="$4"
    local s_ip=$(get_host)
    if id "$username" &>/dev/null; then echo "⚠ User $username sudah ada!"; return; fi
    useradd -M -N -s /bin/bash "$username" && echo "$username:$password" | chpasswd
    chage -E $(date -d "+$expire_days days" +%Y-%m-%d) "$username"
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username.conf"
    local body="User: \`$username\`\nHost/IP: \`$s_ip\`\nPassword: \`$password\`\nExpired: \`$expire_days hari\`\nMax Login: \`$maxlogins\`\nConnect: \`$s_ip:1-65535@$username:$password\`"
    format_msg "SSH UDP CUSTOM" "$body"
}

create_trial() {
    local s_ip=$(get_host)
    local username="trial$(openssl rand -hex 2)"
    while id "$username" &>/dev/null; do username="trial$(openssl rand -hex 3)"; done
    local password=$(openssl rand -base64 6)
    local maxlogins=1
    useradd -M -N -s /bin/bash "$username" && echo "$username:$password" | chpasswd
    chage -E $(date -d "+1 day" +%Y-%m-%d) "$username"
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username.conf"
    local body="User: \`$username\`\nHost/IP: \`$s_ip\`\nPassword: \`$password\`\nExpired: \`1 hari\`\nMax Login: \`$maxlogins\`\nConnect: \`$s_ip:1-65535@$username:$password\`"
    format_msg "SSH UDP CUSTOM (TRIAL)" "$body"
}

renew_user_step() {
    local username="$1" tambah="$2"
    exp_lama=$(chage -l $username | grep "Account expires" | awk -F": " '{print $2}')
    [[ "$exp_lama" == "never" ]] && exp_baru=$(date -d "+$tambah days" +%Y-%m-%d) || exp_baru=$(date -d "$exp_lama + $tambah days" +%Y-%m-%d)
    chage -E $exp_baru $username
    echo "✅ User \`$username\` diperpanjang!\nExpired Lama: \`$exp_lama\`\nExpired Baru: \`$exp_baru\`\nDitambah: \`$tambah hari\`"
}

delete_user() { local username="$1"; id "$username" &>/dev/null || { echo "⚠ User $username tidak ditemukan!"; return; }; userdel -r $username 2>/dev/null; rm -f /etc/security/limits.d/$username.conf; echo "✅ User $username berhasil dihapus!"; }
list_user() { msg="📋 Daftar User Aktif:\n"; for u in $(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd); do exp=$(chage -l $u | grep "Account expires" | awk -F": " '{print $2}'); msg+="$u → $exp\n"; done; echo -e "$msg"; }

# ===== AUTO EXPIRED =====
auto_expired() {
    LOG_FILE="/var/log/expired_users.log"; mkdir -p /var/log; > $LOG_FILE
    for user in $(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd); do
        exp_date=$(chage -l $user | grep "Account expires" | awk -F": " '{print $2}')
        if [[ "$exp_date" != "never" && "$exp_date" != "Account expires" ]]; then
            [[ $(date -d "$exp_date" +%s) -lt $(date +%s) ]] && { echo "$(date) : $user expired ($exp_date) → dihapus" >> $LOG_FILE; userdel -r $user 2>/dev/null; rm -f /etc/security/limits.d/$user.conf; [[ ! -z $CHAT_ID ]] && send_msg "$CHAT_ID" "⚠ User \`$user\` expired ($exp_date) → dihapus otomatis."; }
        fi
    done
}

# ===== BACKUP / RESTORE =====
backup_data() {
    mkdir -p $BACKUP_DIR
    awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd > $BACKUP_DIR/users.list
    > $BACKUP_DIR/shadow.backup
    for u in $(cat $BACKUP_DIR/users.list); do chage -l $u | grep "Account expires" | awk -F": " '{print $2}' > $BACKUP_DIR/$u.expire; grep "^$u:" /etc/shadow >> $BACKUP_DIR/shadow.backup; done
    [[ -f $HOST_FILE ]] && cp $HOST_FILE $BACKUP_DIR/
    tar -czf /root/udp/backup_ssh.tar.gz -C /root/udp backup
    LINK=$(curl -s -F "file=@/root/udp/backup_ssh.tar.gz" https://0x0.st)
    echo "✅ Backup sukses! Link: $LINK"
}

restore_data() {
    local link="$1"
    wget -qO /root/udp/backup_ssh.tar.gz "$link"
    tar -xzf /root/udp/backup_ssh.tar.gz -C /root/udp/
    cd /root/udp/backup
    for u in $(cat users.list); do [[ ! $(id -u $u 2>/dev/null) ]] && useradd -M -N -s /bin/bash $u; shadow_line=$(grep "^$u:" shadow.backup); [[ -n "$shadow_line" ]] && (sed -i "/^$u:/d" /etc/shadow && echo "$shadow_line" >> /etc/shadow); expire=$(cat $u.expire); [[ $expire != "never" ]] && chage -E $(date -d "$expire" +%Y-%m-%d) $u; done
    [[ -f host.conf ]] && cp host.conf $HOST_FILE
    echo "✅ Restore sukses dari link $link"
}

# ===== CRON =====
setup_cron() { CRON_CMD="/bin/bash $0 expired >/dev/null 2>&1"; if ! crontab -l 2>/dev/null | grep -q "$CRON_CMD"; then (crontab -l 2>/dev/null; echo "0 0 * * * $CRON_CMD") | crontab -; echo -e "${GREEN}✅ Cronjob auto expired dipasang${ENDCOLOR}"; fi }

# ===== TELEGRAM BOT =====
send_msg() {
    [[ -z "$BOT_TOKEN" || -z "$1" ]] && return
    curl -s -X POST "https://api.telegram.org/bot${BOT_TOKEN}/sendMessage" -d chat_id="$1" -d parse_mode="MarkdownV2" -d text="$2" ${3:+-d reply_markup="$3"} >/dev/null
}

telegram_bot() {
    [[ -z "$BOT_TOKEN" || -z "$CHAT_ID" ]] && return
    declare -A SESSION
    while true; do
        OFFSET=$(cat $OFFSET_FILE)
        RESPONSE=$(curl -s "https://api.telegram.org/bot$BOT_TOKEN/getUpdates?timeout=30&offset=$OFFSET")
        for row in $(echo "$RESPONSE" | jq -c '.result[]'); do
            UPDATE_ID=$(echo $row | jq '.update_id')
            MSG=$(echo $row | jq -r '.message.text // empty')
            CALLBACK=$(echo $row | jq -r '.callback_query.data // empty')
            OFFSET=$((UPDATE_ID+1)); echo $OFFSET > $OFFSET_FILE
            [[ -z "$MSG" && -z "$CALLBACK" ]] && continue

            # STATE MANAGEMENT
            state=${SESSION["$CHAT_ID"]}
            if [[ "$state" == "await_username" ]]; then SESSION["username"]="$MSG"; SESSION["$CHAT_ID"]="await_password"; send_msg "$CHAT_ID" "Masukkan password untuk user $MSG:"; continue; fi
            if [[ "$state" == "await_password" ]]; then SESSION["password"]="$MSG"; SESSION["$CHAT_ID"]="await_expire"; send_msg "$CHAT_ID" "Masukkan masa aktif (hari) untuk user ${SESSION["username"]}:"; continue; fi
            if [[ "$state" == "await_expire" ]]; then SESSION["expire"]="$MSG"; SESSION["$CHAT_ID"]="await_maxlogin"; send_msg "$CHAT_ID" "Masukkan max login untuk user ${SESSION["username"]}:"; continue; fi
            if [[ "$state" == "await_maxlogin" ]]; then msg=$(create_user "${SESSION["username"]}" "${SESSION["password"]}" "${SESSION["expire"]}" "${SESSION["maxlogin"]}"); send_msg "$CHAT_ID" "$msg"; unset SESSION["$CHAT_ID"]; continue; fi
            if [[ "$state" == "await_renew_username" ]]; then SESSION["username"]="$MSG"; SESSION["$CHAT_ID"]="await_renew_days"; send_msg "$CHAT_ID" "Masukkan jumlah hari tambahan untuk user $MSG:"; continue; fi
            if [[ "$state" == "await_renew_days" ]]; then msg=$(renew_user_step "${SESSION["username"]}" "$MSG"); send_msg "$CHAT_ID" "$msg"; unset SESSION["$CHAT_ID"]; continue; fi

            # HANDLE COMMANDS
            case $MSG in
                /start) send_msg "$CHAT_ID" "Selamat datang di VPS Panel Bot\nKetik /menu untuk memulai." ;;
                /menu)
                    reply='{"inline_keyboard":[[{"text":"Tambah User","callback_data":"add_user"},{"text":"Tambah Trial","callback_data":"add_trial"}],[{"text":"Perpanjang User","callback_data":"renew_user"},{"text":"Hapus User","callback_data":"delete_user"}],[{"text":"List User","callback_data":"list_user"},{"text":"Host/Set Host","callback_data":"host"}],[{"text":"Backup","callback_data":"backup"},{"text":"Restore","callback_data":"restore"}]]}'
                    send_msg "$CHAT_ID" "🌐 Menu VPS Panel" "$reply" ;;
                /delete*) u=$(echo $MSG | awk '{print $2}'); msg=$(delete_user "$u"); send_msg "$CHAT_ID" "$msg" ;;
                /sethost*) h=$(echo $MSG | awk '{print $2}'); set_host "$h";;
                /restore*) link=$(echo $MSG | awk '{print $2}'); msg=$(restore_data "$link"); send_msg "$CHAT_ID" "$msg" ;;
            esac

            case $CALLBACK in
                add_user) SESSION["$CHAT_ID"]="await_username"; send_msg "$CHAT_ID" "Masukkan username baru:" ;;
                add_trial) msg=$(create_trial); send_msg "$CHAT_ID" "$msg" ;;
                renew_user) SESSION["$CHAT_ID"]="await_renew_username"; send_msg "$CHAT_ID" "Masukkan username yang ingin diperpanjang:" ;;
                delete_user) send_msg "$CHAT_ID" "Ketik /delete <username> untuk menghapus user." ;;
                list_user) msg=$(list_user); send_msg "$CHAT_ID" "$msg" ;;
                host) s_ip=$(get_host); send_msg "$CHAT_ID" "Host saat ini: \`$s_ip\`\nKetik /sethost <ip> untuk mengubah host." ;;
                backup) msg=$(backup_data); send_msg "$CHAT_ID" "$msg" ;;
                restore) send_msg "$CHAT_ID" "Ketik /restore <link> untuk merestore backup." ;;
            esac
        done
        sleep 1
    done
}

# ===== START TELEGRAM POLLING BACKGROUND =====
start_telegram_polling_bg() { [[ -z "$BOT_TOKEN" || -z "$CHAT_ID" ]] && return; nohup bash "$0" >/root/udp/telegram_polling.log 2>&1 & echo -e "${GREEN}✅ Telegram polling berjalan di background${ENDCOLOR}"; }

# ===== MENU MANUAL =====
menu2() {
    while true; do
        clear
        echo -e "${YELLOW}╔══════════ VPS PANEL ══════════${ENDCOLOR}"
        echo -e "${YELLOW}║ 1) Tambah User"
        echo -e "${YELLOW}║ 2) Tambah Trial"
        echo -e "${YELLOW}║ 3) Perpanjang User"
        echo -e "${YELLOW}║ 4) Hapus User"
        echo -e "${YELLOW}║ 5) List User Aktif"
        echo -e "${YELLOW}║ 6) Host Aktif"
        echo -e "${YELLOW}║ 7) Set Host"
        echo -e "${YELLOW}║ 8) Reset Host"
        echo -e "${YELLOW}║ 9) Backup"
        echo -e "${YELLOW}║ 10) Restore"
        echo -e "${YELLOW}║ 11) Set Telegram Bot"
        echo -e "${YELLOW}║ 0) Keluar"
        echo -e "${YELLOW}╚══════════════════════════════${ENDCOLOR}"
        read -p "⚡ Pilih menu [0-11]: " pilih
        case $pilih in
            1) read -p "Username: " u; read -p "Password: " p; read -p "Expired (hari): " e; read -p "Max login: " m; create_user "$u" "$p" "$e" "$m" ;;
            2) create_trial ;;
            3) read -p "Username: " u; read -p "Jumlah hari tambahan: " d; renew_user_step "$u" "$d" ;;
            4) read -p "Username: " u; delete_user "$u" ;;
            5) list_user ;;
            6) view_host ;;
            7) read -p "Masukkan host/IP: " h; set_host "$h" ;;
            8) reset_host ;;
            9) backup_data ;;
            10) read -p "Masukkan link backup: " l; restore_data "$l" ;;
            11) read -p "BOT TOKEN: " b; read -p "CHAT ID: " c; echo "BOT_TOKEN=$b" > $TG_CONF; echo "CHAT_ID=$c" >> $TG_CONF; source $TG_CONF ;;
            0|"") exit 0 ;;
            *) echo -e "${RED}⚠ Pilihan salah!${ENDCOLOR}"; sleep 1 ;;
        esac
        echo -e "\nTekan Enter untuk kembali ke menu"; read
    done
}

# ===== START SCRIPT =====
if [[ "$1" == "expired" ]]; then auto_expired; exit 0; else
    setup_cron
    start_telegram_polling_bg
    telegram_bot &
    menu
fi