#!/bin/bash

# ===== COLORS =====
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
ENDCOLOR="\e[0m"

HOST_FILE="/root/udp/host.conf"
BACKUP_DIR="/root/udp/backup"

mkdir -p /root/udp
mkdir -p $BACKUP_DIR

# ===== FUNGSI AMBIL HOST/IP =====
get_host() {
    if [[ -s $HOST_FILE ]]; then
        cat $HOST_FILE
    else
        wget -4 -qO- https://ipecho.net/plain
    fi
}

# ===== AUTO HAPUS USER EXPIRED =====
auto_expired() {
    LOG_FILE="/var/log/expired_users.log"
    mkdir -p /var/log
    > $LOG_FILE

    for user in $(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd); do
        exp_date=$(chage -l $user | grep "Account expires" | awk -F": " '{print $2}')
        if [[ "$exp_date" != "never" && "$exp_date" != "Account expires" ]]; then
            exp_sec=$(date -d "$exp_date" +%s)
            now_sec=$(date +%s)
            if [[ $exp_sec -lt $now_sec ]]; then
                echo "$(date) : $user expired ($exp_date) → dihapus" >> $LOG_FILE
                userdel -r $user 2>/dev/null
            fi
        fi
    done
}

# ===== TAMBAH USER BIASA =====
add_user() {
    s_ip=$(get_host)

    clear
    echo -ne "${YELLOW}Masukkan username: ${ENDCOLOR}"; read username
    if id "$username" &>/dev/null; then
        echo -e "${RED}User $username sudah ada${ENDCOLOR}"
        sleep 2
        return
    fi

    echo -ne "Masukkan password: "; read password
    echo -e "${GREEN}Password set successfully!${ENDCOLOR}"

    echo -ne "Masukkan expired (hari): "; read expire_days
    expire_date=$(date -d "+$expire_days days" +%Y-%m-%d)
    expire_full=$(date -d "+$expire_days days 23:59" +"%Y%m%d%H%M")

    read -p "Max logins limit: " maxlogins
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username"

    useradd -M -N -s /bin/bash $username && echo "$username:$password" | chpasswd
    chage -E $expire_date $username

    # pastikan atd aktif
    if ! systemctl is-active --quiet atd; then
        systemctl start atd
        systemctl enable atd
    fi

    echo "userdel -r $username 2>/dev/null" | at -t $expire_full

    echo -e "\n${GREEN}User $username berhasil dibuat!${ENDCOLOR}"
    echo -e "🌐 Host/IP    : $s_ip\n👤 Username  : $username\n🔑 Password  : $password\n⏳ Expired   : $expire_days hari\n🔒 Max Login : $maxlogins\n"
}

# ===== TAMBAH TRIAL USER =====
add_trial() {
    s_ip=$(get_host)

    username="trial$(openssl rand -hex 2)"
    while id "$username" &>/dev/null; do
        username="trial$(openssl rand -hex 3)"
    done

    password=$(openssl rand -base64 3)
    maxlogins=1
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username"

    useradd -M -N -s /bin/bash $username && echo "$username:$password" | chpasswd
    chage -E $(date -d "+15 minutes" +%Y-%m-%d)

    if ! systemctl is-active --quiet atd; then
        systemctl start atd
        systemctl enable atd
    fi

    echo "userdel -r $username 2>/dev/null" | at now + 15 minutes

    echo -e "\n${GREEN}Trial user $username berhasil dibuat!${ENDCOLOR}"
    echo -e "🌐 Host/IP  : $s_ip\n👤 Username : $username\n🔑 Password : $password\n⏳ Expired  : 15 menit\n🔒 Max Login: $maxlogins\n"
}

# ===== HOST MANAGEMENT =====
add_host() {
    echo -ne "${YELLOW}Masukkan IP/Host baru: ${ENDCOLOR}"; read host
    echo "$host" > $HOST_FILE
    echo -e "${GREEN}Host berhasil disimpan: $host${ENDCOLOR}"
}

reset_host() {
    if [[ -f $HOST_FILE ]]; then
        rm -f $HOST_FILE
        echo -e "${GREEN}Host berhasil direset, kembali ke IP VPS.${ENDCOLOR}"
    else
        echo -e "${YELLOW}Belum ada host custom yang diset.${ENDCOLOR}"
    fi
}

view_host() {
    echo -e "${CYAN}Host/IP yang aktif:${ENDCOLOR} $(get_host)"
}

# ===== BACKUP & RESTORE =====
backup_data() {
    awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd > $BACKUP_DIR/users.list

    > $BACKUP_DIR/shadow.backup
    for u in $(cat $BACKUP_DIR/users.list); do
        chage -l $u | grep "Account expires" | awk -F": " '{print $2}' > $BACKUP_DIR/$u.expire
        grep "^$u:" /etc/shadow >> $BACKUP_DIR/shadow.backup
    done

    [[ -f $HOST_FILE ]] && cp $HOST_FILE $BACKUP_DIR/

    tar -czf /root/udp/backup_ssh.tar.gz -C /root/udp backup
    LINK=$(curl -s -F "file=@/root/udp/backup_ssh.tar.gz" https://0x0.st)
    echo -e "${GREEN}Backup sukses! Link: ${CYAN}$LINK${ENDCOLOR}"
}

restore_data() {
    echo -ne "${YELLOW}Masukkan link backup: ${ENDCOLOR}"; read link
    wget -qO /root/udp/backup_ssh.tar.gz "$link"
    tar -xzf /root/udp/backup_ssh.tar.gz -C /root/udp/

    cd /root/udp/backup
    for u in $(cat users.list); do
        [[ ! $(id -u $u 2>/dev/null) ]] && useradd -M -N -s /bin/bash "$u"
        shadow_line=$(grep "^$u:" shadow.backup)
        [[ -n "$shadow_line" ]] && sed -i "/^$u:/d" /etc/shadow && echo "$shadow_line" >> /etc/shadow

        expire=$(cat $u.expire)
        [[ $expire != "never" ]] && chage -E $(date -d "$expire" +%Y-%m-%d) $u
    done

    [[ -f host.conf ]] && cp host.conf $HOST_FILE
    echo -e "${GREEN}Restore sukses dari link $link${ENDCOLOR}"
}

# ===== LIST USER =====
list_user() {
    echo -e "${CYAN}Daftar User SSH Aktif:${ENDCOLOR}"
    echo "==============================="
    printf "%-15s %-20s\n" "Username" "Expired Date"
    echo "-------------------------------"
    total=0
    for u in $(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd); do
        exp=$(chage -l $u | grep "Account expires" | awk -F": " '{print $2}')
        printf "%-15s %-20s\n" "$u" "$exp"
        ((total++))
    done
    echo "-------------------------------"
    echo -e "Total User Aktif : ${GREEN}$total${ENDCOLOR}"
}

# ===== START SCRIPT =====
clear
echo -e "${YELLOW}🌐 Starting SSH & UDP Management Script...${ENDCOLOR}"

# Jalankan auto expired dulu
auto_expired

# Menu sederhana
while true; do
    echo -e "\n${YELLOW}╔══ Menu ════════════════════════${ENDCOLOR}"
    echo -e "${YELLOW}║ 1) Tambah User${ENDCOLOR}"
    echo -e "${YELLOW}║ 2) Tambah Trial${ENDCOLOR}"
    echo -e "${YELLOW}║ 3) Tambah Host${ENDCOLOR}"
    echo -e "${YELLOW}║ 4) Reset Host${ENDCOLOR}"
    echo -e "${YELLOW}║ 5) Lihat Host${ENDCOLOR}"
    echo -e "${YELLOW}║ 6) Backup${ENDCOLOR}"
    echo -e "${YELLOW}║ 7) Restore${ENDCOLOR}"
    echo -e "${YELLOW}║ 8) List User${ENDCOLOR}"
    echo -e "${YELLOW}║ 0) Keluar${ENDCOLOR}"
    echo -e "${YELLOW}╚════════════════════════════════${ENDCOLOR}"

    read -p "Pilih menu [0-8]: " pilih
    case $pilih in
        1) add_user ;;
        2) add_trial ;;
        3) add_host ;;
        4) reset_host ;;
        5) view_host ;;
        6) backup_data ;;
        7) restore_data ;;
        8) list_user ;;
        0|"") exit 0 ;;
        *) echo -e "${RED}Pilihan salah!${ENDCOLOR}" ;;
    esac
done