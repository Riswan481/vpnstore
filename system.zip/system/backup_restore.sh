#!/bin/bash

BACKUP_DIR="/root/backup"
RESTORE_DIR="/root/restore"
DATE=$(date +"%Y-%m-%d_%H-%M")

backup_data() {
    mkdir -p $BACKUP_DIR
    BACKUP_FILE="backup-$DATE.tar.gz"
    echo "📦 Membuat file backup..."
    tar -czf $BACKUP_DIR/$BACKUP_FILE \
        /etc/passwd /etc/shadow /etc/group /etc/gshadow \
        /var/lib /root
    echo "☁️ Upload ke Google Drive..."
    FILE_ID=$(gdrive upload --parent root $BACKUP_DIR/$BACKUP_FILE | awk '{print $2}' | tail -n1)
    echo "✅ Backup selesai!"
    echo "🔗 https://drive.google.com/uc?id=$FILE_ID&export=download"
    read -p "Enter untuk kembali..."
}

restore_data() {
    mkdir -p $RESTORE_DIR
    cd $RESTORE_DIR || exit
    read -p "Masukkan FILE ID Google Drive: " FILE_ID
    gdrive download $FILE_ID --force
    BACKUP_FILE=$(ls backup-*.tar.gz | tail -n1)
    [[ -f "$BACKUP_FILE" ]] && tar -xzf "$BACKUP_FILE" -C / && echo "♻️ Restore selesai!" || echo "❌ File tidak ditemukan!"
    read -p "Enter untuk kembali..."
}

submenu() {
    clear
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "      🔐 BACKUP & RESTORE     "
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "1) Backup ke Google Drive"
    echo "2) Restore dari Google Drive"
    echo "0) Kembali"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    read -p "Pilih: " sub
    case $sub in
        1) backup_data ;;
        2) restore_data ;;
        0) exit 0 ;;
        *) echo "Pilihan tidak valid!" ;;
    esac
}

submenu