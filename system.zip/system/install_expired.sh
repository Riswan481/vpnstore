#!/bin/bash
# Auto Delete Expired Users – langsung jalan otomatis tiap 5 menit

SCRIPT_PATH="/usr/local/bin/expired_user.sh"
LOG_FILE="/var/log/expired_users.log"

# Buat script auto hapus
cat > $SCRIPT_PATH <<'EOF'
#!/bin/bash
LOG_FILE="/var/log/expired_users.log"

allusers=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody)

for user in $allusers; do
    exp=$(chage -l "$user" 2>/dev/null | grep "Account expires" | cut -d: -f2 | xargs)
    if [[ "$exp" =~ "Never" || "$exp" =~ "never" ]]; then continue; fi
    exp_date=$(date -d "$exp" +"%Y-%m-%d" 2>/dev/null)
    exp_full="$exp_date 23:59:59"
    today=$(date +%s)
    exp_epoch=$(date -d "$exp_full" +%s 2>/dev/null)
    [[ -z "$exp_epoch" ]] && continue
    sisa=$(( (exp_epoch - today + 86399) / 86400 ))
    if [ $sisa -le 0 ]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') : $user expired ($exp_full) → dihapus" >> $LOG_FILE
        userdel -r "$user" &>/dev/null
        rm -f /etc/security/limits.d/"$user" 2>/dev/null
    fi
done
EOF

# Kasih izin eksekusi
chmod +x $SCRIPT_PATH

# Pasang cronjob otomatis tiap 5 menit
(crontab -l 2>/dev/null | grep -v "$SCRIPT_PATH"; echo "*/5 * * * * $SCRIPT_PATH >/dev/null 2>&1") | crontab -

# Jalankan script langsung sekali
$SCRIPT_PATH

echo -e "\e[32m✅ Script berhasil dipasang dan langsung jalan otomatis tiap 5 menit\e[0m"
echo -e "Log: $LOG_FILE"