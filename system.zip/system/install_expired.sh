#!/bin/bash
# Installer Auto Delete Expired Users

SCRIPT_PATH="/usr/local/bin/expired_user.sh"
LOG_FILE="/var/log/expired_users.log"

# ====== BUAT SCRIPT AUTO HAPUS ======
cat > $SCRIPT_PATH <<'EOF'
#!/bin/bash
# Auto remove expired users

LOG_FILE="/var/log/expired_users.log"

allusers=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody)

for user in $allusers; do
    exp=$(chage -l "$user" 2>/dev/null | grep "Account expires" | cut -d: -f2 | xargs)

    if [[ "$exp" =~ "Never" || "$exp" =~ "never" ]]; then
        continue
    fi

    exp_date=$(date -d "$exp" +"%Y-%m-%d" 2>/dev/null)
    exp_full="$exp_date 23:59:59"

    today=$(date +%s)
    exp_epoch=$(date -d "$exp_full" +%s 2>/dev/null)

    [[ -z "$exp_epoch" ]] && continue

    # +86399 supaya sisa jam masih dihitung 1 hari
    sisa=$(( (exp_epoch - today + 86399) / 86400 ))

    if [ $sisa -le 0 ]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') : $user expired ($exp_full) → dihapus" >> $LOG_FILE
        userdel -r "$user" &>/dev/null
        rm -f /etc/security/limits.d/"$user" 2>/dev/null
    fi
done
EOF

# ====== KASIH IZIN EKSEKUSI ======
chmod +x $SCRIPT_PATH

# ====== PASANG CRON JOB (tiap 5 menit) ======
(crontab -l 2>/dev/null | grep -v "$SCRIPT_PATH" ; echo "*/5 * * * * $SCRIPT_PATH >/dev/null 2>&1") | crontab -

echo -e "\e[32m✅ Installer selesai!"
echo -e "Script disimpan di: $SCRIPT_PATH"
echo -e "Log expired user: $LOG_FILE"
echo -e "Cronjob otomatis sudah dipasang (jalan tiap 5 menit)\e[0m"