cat << 'EOF' > /root/expired_user.sh
#!/bin/bash

LOG_FILE="/var/log/expired_users.log"
mkdir -p /var/log
> $LOG_FILE

for user in $(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd); do
    exp_date=$(chage -l $user | grep "Account expires" | awk -F": " '{print $2}')
    if [[ "$exp_date" != "never" && "$exp_date" != "Account expires" ]]; then
        exp_sec=$(date -d "$exp_date" +%s)
        now_sec=$(date +%s)
        if [[ $exp_sec -lt $now_sec ]]; then
            userdel -r $user 2>/dev/null
            echo "$(date) : User $user expired ($exp_date) → dihapus" >> $LOG_FILE
        fi
    fi
done
EOF

# Beri izin eksekusi otomatis
chmod +x /root/expired_user.sh