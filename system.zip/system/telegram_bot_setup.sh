#!/bin/bash
CONFIG_FILE="/root/udp/telegram_bot.conf"

read -rp "Enter your Telegram Bot Token: " BOT_TOKEN
read -rp "Enter your Telegram Admin Chat ID: " CHAT_ID

cat > "$CONFIG_FILE" <<EOF
BOT_TOKEN="$BOT_TOKEN"
CHAT_ID="$CHAT_ID"
EOF

BOT_SCRIPT="/root/udp/telegram_bot_main.sh"
if [ ! -f "$BOT_SCRIPT" ]; then
    echo "Bot script not found! Copy telegram_bot_main.sh to /root/udp/"
fi

SERVICE_FILE="/etc/systemd/system/telegram-vpn-bot.service"
cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Telegram VPN Bot
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/udp
ExecStart=/bin/bash /root/udp/telegram_bot_main.sh
Restart=always
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable telegram-vpn-bot
systemctl start telegram-vpn-bot
echo "✅ Telegram Bot is now running with auto-restart"