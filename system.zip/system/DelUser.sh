#!/bin/bash

# ===== COLORS =====
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
ENDCOLOR="\e[0m"

clear

# ===== HEADER =====
echo -e "${CYAN}========================================${ENDCOLOR}"
echo -e "${CYAN}           USER MANAGEMENT TOOL         ${ENDCOLOR}"
echo -e "${CYAN}========================================${ENDCOLOR}"
echo ""

# ===== MENU =====
echo -e "${GREEN}1) Delete User Manually${ENDCOLOR}"
echo -e "${GREEN}2) Delete Expired Users${ENDCOLOR}"
echo -e "${CYAN}----------------------------------------${ENDCOLOR}"
echo -ne "Choose option [1-2]: "; read option

case $option in
1)
    # ===== Tampilkan Semua User =====
    allusers=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody)
    echo -e "${GREEN}List of users:${ENDCOLOR}"
    echo -e "${GREEN}$allusers${ENDCOLOR}"
    echo -e "${CYAN}----------------------------------------${ENDCOLOR}"
    echo ""
    
    # ===== Hapus User =====
    echo -ne "${YELLOW}Enter the name of the user to be deleted: ${ENDCOLOR}"; read username
    
    echo -e "${CYAN}----------------------------------------${ENDCOLOR}"
    while true; do
        read -p "Do you want to delete the user '$username'? (Y/N) " yn
        case $yn in
            [Yy]* )
                if id "$username" &>/dev/null; then
                    if userdel -r "$username"; then
                        echo -e "${GREEN}User '$username' deleted successfully.${ENDCOLOR}"
                    else
                        echo -e "${RED}Failed to delete user '$username'.${ENDCOLOR}"
                    fi
                else
                    echo -e "${RED}User '$username' does not exist.${ENDCOLOR}"
                fi
                break
                ;;
            [Nn]* )
                echo -e "${YELLOW}Delete cancelled.${ENDCOLOR}"
                break
                ;;
            * )
                echo -e "${RED}Please answer Y or N.${ENDCOLOR}"
                ;;
        esac
    done
    ;;
2)
    echo -e "${YELLOW}Checking expired users...${ENDCOLOR}"
    today=$(date +%s)

    while read user expdate; do
        exp_sec=$(date -d "$expdate" +%s 2>/dev/null)
        if [[ $today -ge $exp_sec ]]; then
            if id "$user" &>/dev/null; then
                userdel -r "$user"
                echo -e "${RED}User '$user' expired on $expdate and deleted.${ENDCOLOR}"
            fi
        fi
    done < /etc/expuser.conf

    echo -e "${GREEN}Expired user check completed.${ENDCOLOR}"
    ;;
*)
    echo -e "${RED}Invalid option.${ENDCOLOR}"
    ;;
esac

echo -e "${CYAN}========================================${ENDCOLOR}"
echo -e "Press Enter to return to main menu"; read