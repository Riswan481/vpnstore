#!/bin/bash
# =========================================
#       USER MANAGEMENT TOOL
# =========================================

# ===== COLORS =====
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
ENDCOLOR="\e[0m"

# ===== FILE KONFIG =====
EXP_FILE="/etc/expuser.conf"
LOG_FILE="/var/log/deluser.log"

clear
echo -e "${CYAN}========================================${ENDCOLOR}"
echo -e "${CYAN}           USER MANAGEMENT TOOL         ${ENDCOLOR}"
echo -e "${CYAN}========================================${ENDCOLOR}"
echo ""
echo -e "1) Auto delete expired users"
echo -e "2) Manual delete user"
echo -e "0) Exit"
echo ""
read -p "Select menu [0-2]: " choice
echo ""

case $choice in
    1)
        echo -e "${YELLOW}Checking expired users...${ENDCOLOR}"
        if [ ! -f "$EXP_FILE" ]; then
            echo "Tidak ada file expired user" | tee -a "$LOG_FILE"
            exit 0
        fi

        TODAY=$(date +%s)

        while read user exp_date; do
            # Lewati baris kosong
            [ -z "$user" ] && continue

            exp_epoch=$(date -d "$exp_date" +%s 2>/dev/null)
            if [ -z "$exp_epoch" ]; then
                echo "Tanggal tidak valid untuk user $user → dilewati" | tee -a "$LOG_FILE"
                continue
            fi

            if [ $TODAY -ge $exp_epoch ]; then
                if id "$user" &>/dev/null; then
                    userdel -r "$user" 2>/dev/null
                    echo "User $user expired ($exp_date) → dihapus" | tee -a "$LOG_FILE"
                else
                    echo "User $user tidak ada di sistem → dilewati" | tee -a "$LOG_FILE"
                fi
            fi
        done < "$EXP_FILE"
        echo -e "${GREEN}Selesai cek expired users.${ENDCOLOR}"
        ;;
    2)
        # ===== Tampilkan Semua User =====
        allusers=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody)
        echo -e "${GREEN}List of users:${ENDCOLOR}"
        echo -e "${GREEN}$allusers${ENDCOLOR}"
        echo -e "${CYAN}----------------------------------------${ENDCOLOR}"
        echo ""

        # ===== Hapus User =====
        echo -ne "${YELLOW}Enter the name of the user to be deleted: ${ENDCOLOR}"; read username

        echo -e "${CYAN}----------------------------------------${ENDCOLOR}"
        while true; do
            read -p "Do you want to delete the user '$username'? (Y/N) " yn
            case $yn in
                [Yy]* )
                    if id "$username" &>/dev/null; then
                        if userdel -r "$username"; then
                            echo -e "${GREEN}User '$username' deleted successfully.${ENDCOLOR}"
                        else
                            echo -e "${RED}Failed to delete user '$username'.${ENDCOLOR}"
                        fi
                    else
                        echo -e "${RED}User '$username' does not exist.${ENDCOLOR}"
                    fi
                    break
                    ;;
                [Nn]* )
                    echo -e "${YELLOW}Delete cancelled.${ENDCOLOR}"
                    break
                    ;;
                * )
                    echo -e "${RED}Please answer Y or N.${ENDCOLOR}"
                    ;;
            esac
        done
        ;;
    0)
        echo -e "${YELLOW}Exit.${ENDCOLOR}"
        exit 0
        ;;
    *)
        echo -e "${RED}Invalid option!${ENDCOLOR}"
        ;;
esac

echo -e "${CYAN}========================================${ENDCOLOR}"
echo -e "Press Enter to return"; read