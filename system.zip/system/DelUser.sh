#!/bin/bash

RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
ENDCOLOR="\e[0m"

clear

# Tampilkan semua user
allusers=$(awk -F: '$3>=1000 {print $1}' /etc/passwd | grep -v nobody)
echo -e "${GREEN}List of users:${ENDCOLOR}"
echo -e "${GREEN}$allusers${ENDCOLOR}"
echo ""

# Hapus user
echo -ne "${YELLOW}Enter the name of the user to be deleted: "; read username

while true; do
    read -p "Do you want to delete the user $username? (Y/N) " yn
    case $yn in
        [Yy]* )
            if userdel $username; then
                echo -e "${RED}User $username deleted successfully.${ENDCOLOR}"
            else
                echo -e "${RED}Failed to delete user $username.${ENDCOLOR}"
            fi
            break
            ;;
        [Nn]* )
            echo -e "${RED}Delete cancelled.${ENDCOLOR}"
            break
            ;;
        * ) echo "Please answer yes or no.";;
    esac
done

echo -e "\nPress Enter key to return to main menu"; read
menu