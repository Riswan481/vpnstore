#!/bin/bash
export HOME=/root
export TERM=xterm

NC='\e[0m'
RED='\e[1;31m'
GREEN='\e[1;32m'

enge="If disconnected, please enter the following command in the VPS: <code>screen -r -d setup</code> and press Enter."
indon="Jika Disconnect Saat Proses Penginstallan, Silahkan Masukkan Perintah Berikut Di VPS Untuk Menghubungkan Ulang: <code>screen -r -d setup</code> dan tekan Enter."

step1="sysctl -w net.ipv6.conf.all.disable_ipv6=1 && sysctl -w net.ipv6.conf.default.disable_ipv6=1 && apt update -y && apt upgrade -y && apt install -y bzip2 gzip coreutils screen curl unzip && apt install lolcat -y && gem install lolcat && sleep 2 && reboot"
step2='screen -S setupku bash -c "wget -q https://raw.githubusercontent.com/script-vpn-premium/vip/main/setup-main.sh && chmod +x setup-main.sh && sed -i -e '\''s/\r$//'\'' setup-main.sh && ./setup-main.sh; read -p \"Tekan enter untuk keluar...\""'

# Ambil tanggal dari server
dateFromServer=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
date_list=$(date +"%Y-%m-%d" -d "$dateFromServer")
ipsaya=$(curl -sS ipv4.icanhazip.com)

# Cek IP aktif dari database REGIST
data_ip="https://raw.githubusercontent.com/script-vpn-premium/vip/main/REGIST"

checking_sc() {
  useexp=$(wget -qO- $data_ip | grep $ipsaya | awk '{print $3}')
  if [[ $date_list < $useexp ]]; then
    echo -ne
  else
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    echo -e "\033[42m          ANDA HARUS MENDAFTAR DAHULU UNTUK MENGGUNAKAN SCRIPT INI         \033[0m"
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    echo -e ""
    echo -e "            ${RED}DAFTAR DULU DEK !${NC}"
    echo -e "   \033[0;33mYour VPS${NC} $ipsaya \033[0;33mHas been Banned${NC}"
    echo -e "     \033[0;33mBuy access permissions for scripts${NC}"
    echo -e "             \033[0;33mContact Admin :${NC}"
    echo -e "      \033[0;36mTelegram${NC} t.me/JesVpnt"
    echo -e "      ${GREEN}WhatsApp${NC} wa.me/6285888801241"
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    exit
  fi
}
checking_sc

# Setting GitHub Info
TOKEN="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"
REPO="https://github.com/script-vpn-premium/vip.git"
EMAIL="serverpremium32@gmail.com"
USER="script-vpn-premium"
today=$(date -d "0 days" +"%Y-%m-%d")

# Parameter dari input
ip="$1"
name="$2"
exp="$3"

# Clone repo ke folder sementara
git clone ${REPO} /root/ipvps/
CLIENT_EXISTS=$(grep -w $ip /root/ipvps/REGIST | wc -l)
if [[ ${CLIENT_EXISTS} == '1' ]]; then
  echo "IP Already Exist !"
  rm -rf /root/ipvps
  exit 0
fi

# Hitung tanggal expired
exp2=`date -d "${exp} days" +"%Y-%m-%d"`
echo "### ${name} ${exp2} ${ip}" >> /root/ipvps/REGIST

# Commit dan push ke GitHub
cd /root/ipvps
git config --global user.email "${EMAIL}"
git config --global user.name "${USER}"
rm -rf .git &> /dev/null
git init &> /dev/null
git add . &> /dev/null
git commit -m "add IP $ip" &> /dev/null
git branch -M main &> /dev/null
git remote add origin https://github.com/script-vpn-premium/vip.git
git push -f https://${TOKEN}@github.com/script-vpn-premium/vip.git &> /dev/null
rm -rf /root/ipvps

# Notifikasi berhasil
echo -e "◇━━━━━━━━━━━━━━━━━━━◇"
echo -e "◇⟨IP SUCCESSFULLY REGISTER⟩◇"
echo -e "◇━━━━━━━━━━━━━━━━━━━◇"
echo -e "🏷️ Client Name : $name"
echo -e "✨IP Address  : $ip"
echo -e "📅 ️Expiry Date : $exp2"
echo -e "◇━━━━━━━━━━━━━━━━━━━◇"
echo -e "❇️ Langkah Pertama:"
echo -e "<code>$step1</code>"
echo -e "◇━━━━━━━━━━━━━━━━━━━◇"
echo -e "❇️ Langkah Kedua:"
echo -e "<code>$step2</code>"
echo -e "◇━━━━━━━━━━━━━━━━━━━◇"
echo -e "<code>$indon</code>"
echo -e "◇━━━━━━━━━━━━━━━━━━━◇"